import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini AI Client if GEMINI_API_KEY is available
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// BeyondWords Guide Assistant Endpoint
app.post('/api/assistant/chat', async (req, res) => {
  const { message, currentSign, contextHistory } = req.body;

  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Message is required' });
  }

  // Pre-compiled expert answers for fast offline / fallback responsiveness
  const lowerMsg = message.toLowerCase();
  
  // If Gemini client is available, leverage gemini-3.8-flash for intelligent sign language tutoring
  if (aiClient) {
    try {
      const systemInstruction = `You are 'BeyondWords Guide', an expert and empathetic American Sign Language (ASL) coach and deaf culture advocate.
Your mission is to help hearing learners master ASL gestures with proper hand anatomy, finger positions, orientation, movement, and facial expressions.
Keep your answers supportive, encouraging, concise (2-4 short paragraphs or bullet points), and physically actionable.
If the learner asks about making a sign (like letters A-J, numbers 1-5, or basic words Hello, Thank You, Yes, No, Help), give crystal-clear finger-by-finger formation instructions.
If they mention mistakes or incorrect detection, explain common errors (e.g. thumb tucked inside vs resting outside, wrist angle, finger curling).
Currently the user is practicing: "${currentSign || 'General ASL Practice'}".`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: message,
        config: {
          systemInstruction,
        },
      });

      return res.json({
        reply: response.text || 'I am here to help you master ASL! Feel free to ask about any gesture or finger placement.',
        source: 'gemini',
      });
    } catch (err: any) {
      console.error('Gemini API call failed, falling back to expert ASL engine:', err?.message || err);
      // Fall through to deterministic expert engine
    }
  }

  // Deterministic high-quality knowledge engine for sign language
  let fallbackReply = '';
  if (lowerMsg.includes('how do i make') || lowerMsg.includes('how to make') || lowerMsg.includes('form') || lowerMsg.includes('sign a')) {
    if (lowerMsg.includes(' a')) {
      fallbackReply = 'To form ASL "A":\n1. Make a tight fist with all four fingers curled into your palm.\n2. Rest your thumb straight upright against the side of your index finger.\n3. Keep your palm facing forward toward the camera or conversational partner.';
    } else if (lowerMsg.includes(' b')) {
      fallbackReply = 'To form ASL "B":\n1. Hold all four fingers straight up, touching tightly together.\n2. Fold your thumb flat across the front of your palm.\n3. Palm faces forward toward the viewer.';
    } else if (lowerMsg.includes(' c')) {
      fallbackReply = 'To form ASL "C":\n1. Curve all your fingers and thumb in an arch to create a "C" shape profile.\n2. Keep fingers relaxed together.\n3. Turn your hand slightly sideways so the curve is distinct.';
    } else if (lowerMsg.includes('hello')) {
      fallbackReply = 'To sign "Hello":\n1. Start with an open flat hand (like "B") near your temple/forehead.\n2. Move your hand outward and slightly forward in a gentle salute motion.\n3. Smile naturally to accompany the greeting!';
    } else if (lowerMsg.includes('thank')) {
      fallbackReply = 'To sign "Thank You":\n1. Touch the fingertips of your flat dominant hand to your chin or lips.\n2. Move the hand outward and forward toward the other person, palm facing up.';
    } else {
      fallbackReply = `To perform the "${currentSign || 'target'}" sign, check the animated visual guide on screen! Ensure your hand is directly centered in the camera frame, with good lighting and fingers fully visible.`;
    }
  } else if (lowerMsg.includes('incorrect') || lowerMsg.includes('mistake') || lowerMsg.includes('wrong') || lowerMsg.includes('why')) {
    fallbackReply = 'Common reasons for incorrect gesture detection:\n• Thumb Placement: Verify if your thumb should be curled across the palm (like "B") or resting on the side (like "A").\n• Camera Distance: Keep your hand about 1.5 to 2 feet from the lens.\n• Lighting: Ensure light is shining on your palm rather than behind you (backlighting obscures landmarks).\n• Angle: Face your palm squarely towards the webcam.';
  } else if (lowerMsg.includes('culture') || lowerMsg.includes('deaf') || lowerMsg.includes('etiquette')) {
    fallbackReply = 'Key ASL & Deaf Etiquette tips:\n1. Maintain eye contact — eye contact is respectful and essential for reading facial grammar.\n2. Don’t worry about speaking out loud while signing; facial expressions are the grammar of ASL.\n3. Always be patient and open to learning from deaf community members.';
  } else {
    fallbackReply = `Welcome to BeyondWords! I am your AI Sign Language Coach. You can ask me how to form any letter (A-J), number (1-5), or words like Hello, Thank You, Yes, No, and Help. What gesture would you like to master today?`;
  }

  return res.json({
    reply: fallbackReply,
    source: 'local-expert',
  });
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`BeyondWords server running on port ${PORT}`);
  });
}

startServer();
