import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { LandingSections } from './components/LandingSections';
import { LessonMode } from './components/LessonMode';
import { QuizMode } from './components/QuizMode';
import { GamificationDashboard } from './components/GamificationDashboard';
import { UserProfile } from './components/UserProfile';
import { AdminPanel } from './components/AdminPanel';
import { BeyondWordsGuide } from './components/BeyondWordsGuide';
import { AuthModal } from './components/AuthModal';
import { DemoWalkthroughModal } from './components/DemoWalkthroughModal';
import { storageService } from './services/storageService';
import { audioService } from './services/audioService';

export default function App() {
  const [currentTab, setCurrentTab] = useState<
    'home' | 'lessons' | 'quiz' | 'dashboard' | 'profile' | 'impact' | 'admin'
  >('home');
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  const [isHighContrast, setIsHighContrast] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [guideSign, setGuideSign] = useState<string>('A');
  const [userProgress, setUserProgress] = useState(storageService.getUserProgress());

  // Sync user progress
  const refreshUserData = () => {
    setUserProgress(storageService.getUserProgress());
  };

  const handleToggleMute = () => {
    const muted = audioService.toggleMute();
    setIsMuted(muted);
  };

  const handleToggleContrast = () => {
    setIsHighContrast((prev) => !prev);
  };

  const handleTabChange = (tab: string) => {
    if (tab === 'impact') {
      setCurrentTab('home');
      setTimeout(() => {
        const el = document.getElementById('social-impact');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
      return;
    }
    setCurrentTab(tab as any);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen bg-slate-50 text-slate-900 ${isHighContrast ? 'high-contrast' : ''}`}>
      {/* Top Bar Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={handleTabChange}
        onOpenAuth={() => setIsAuthOpen(true)}
        isHighContrast={isHighContrast}
        onToggleContrast={handleToggleContrast}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        userLevel={userProgress.level}
      />

      {/* Main App View Routing */}
      <main>
        {currentTab === 'home' && (
          <>
            <Hero
              onStartLearning={() => handleTabChange('lessons')}
              onWatchDemo={() => setIsDemoOpen(true)}
            />
            <LandingSections onStartLearning={() => handleTabChange('lessons')} />
          </>
        )}

        {currentTab === 'lessons' && (
          <LessonMode
            onOpenGuideForSign={(sign) => setGuideSign(sign)}
            onXPUpdated={refreshUserData}
          />
        )}

        {currentTab === 'quiz' && <QuizMode onXPUpdated={refreshUserData} />}

        {currentTab === 'dashboard' && <GamificationDashboard />}

        {currentTab === 'profile' && (
          <UserProfile onBackToLessons={() => handleTabChange('lessons')} />
        )}

        {currentTab === 'admin' && <AdminPanel />}
      </main>

      {/* Floating Doubt Solver AI Assistant: BeyondWords Guide */}
      <BeyondWordsGuide currentSign={guideSign} />

      {/* Auth Modal (Login / Register / Password Reset) */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onAuthSuccess={(u) => {
          setUserProgress(u);
          setIsAuthOpen(false);
        }}
      />

      {/* Interactive Walkthrough Demo Modal */}
      <DemoWalkthroughModal
        isOpen={isDemoOpen}
        onClose={() => setIsDemoOpen(false)}
        onStartLearning={() => handleTabChange('lessons')}
      />
    </div>
  );
}
