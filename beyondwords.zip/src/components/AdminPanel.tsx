import React, { useState } from 'react';
import {
  ShieldAlert,
  Download,
  Plus,
  Users,
  Database,
  BarChart2,
  Trash2,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { GESTURES } from '../data/gestures';

export const AdminPanel: React.FC = () => {
  const user = storageService.getUserProgress();
  const [gesturesList, setGesturesList] = useState(GESTURES);
  const [newSignName, setNewSignName] = useState('');
  const [newSignCategory, setNewSignCategory] = useState<'letters' | 'numbers' | 'words'>('words');
  const [newSignDesc, setNewSignDesc] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  // Export performance data as JSON
  const handleExportJSON = () => {
    const data = {
      exportTimestamp: new Date().toISOString(),
      userProfile: user,
      curriculumCount: gesturesList.length,
      gestures: gesturesList,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `beyondwords_performance_export_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setStatusMessage('Exported performance data as JSON.');
    setTimeout(() => setStatusMessage(''), 3000);
  };

  // Export as CSV
  const handleExportCSV = () => {
    let csv = 'Sign_ID,Sign_Name,Category,Difficulty,Learner_Mastery_Pct\n';
    gesturesList.forEach((g) => {
      const mastery = user.gestureMastery[g.id] || 0;
      csv += `"${g.id}","${g.name}","${g.category}","${g.difficulty}",${mastery}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `beyondwords_gestures_mastery_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    setStatusMessage('Exported performance data as CSV.');
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const handleAddNewGesture = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSignName.trim()) return;

    const newGesture = {
      id: newSignName.trim(),
      name: newSignName.trim(),
      category: newSignCategory,
      difficulty: 'Intermediate' as const,
      shortDesc: newSignDesc || 'Custom admin gesture added to curriculum.',
      handOrientation: 'Palm facing forward toward camera.',
      steps: ['Form the target shape and hold steady for 1.5 seconds.'],
      commonMistakes: ['Ensure full hand visibility.'],
      correctionTip: 'Keep fingers aligned.',
      fingerStateDescription: 'Custom gesture configuration.',
      svgHandType: 'custom',
      idealFingerExtensions: [0.5, 0.5, 0.5, 0.5, 0.5] as [number, number, number, number, number],
    };

    setGesturesList((prev) => [...prev, newGesture]);
    setNewSignName('');
    setNewSignDesc('');
    setStatusMessage(`Gesture "${newGesture.name}" added successfully!`);
    setTimeout(() => setStatusMessage(''), 3000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Admin Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
              System Administration
            </span>
            <span className="text-xs text-slate-500">Instructor & Analytics Dashboard</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mt-1">BeyondWords Control Center</h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl transition-colors shadow-2xs"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleExportJSON}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Aggregate Learner Telemetry Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Curriculum Gestures</span>
          <p className="text-2xl font-black text-slate-900 mt-1">{gesturesList.length}</p>
          <span className="text-[10px] text-teal-600 font-semibold">Active & Trackable</span>
        </div>
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Learner XP Total</span>
          <p className="text-2xl font-black text-blue-600 mt-1">{user.xp}</p>
          <span className="text-[10px] text-slate-400">Level: {user.level}</span>
        </div>
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Completed Lessons</span>
          <p className="text-2xl font-black text-emerald-600 mt-1">
            {user.completedLessons.length}
          </p>
          <span className="text-[10px] text-slate-400">
            {Math.round((user.completedLessons.length / gesturesList.length) * 100)}% Coverage
          </span>
        </div>
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Quiz Records</span>
          <p className="text-2xl font-black text-amber-600 mt-1">{user.quizScores.length}</p>
          <span className="text-[10px] text-slate-400">Recorded Sessions</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column (Col 1-7): Gestures Management */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">Registered Gestures Index</h2>
            <span className="text-xs text-slate-400">{gesturesList.length} total</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
            {gesturesList.map((g, i) => (
              <div key={i} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{g.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 capitalize">
                      {g.category}
                    </span>
                    <span className="text-[10px] text-slate-400">{g.difficulty}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{g.shortDesc}</p>
                </div>
                <span className="font-mono text-teal-600 font-semibold shrink-0">
                  {user.gestureMastery[g.id] || 0}% mastery
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column (Col 8-12): Add New Gesture Form */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-blue-600" />
            <h2 className="text-base font-bold text-slate-900">Add New Gesture to Curriculum</h2>
          </div>

          <form onSubmit={handleAddNewGesture} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Gesture Name / Symbol
              </label>
              <input
                type="text"
                required
                value={newSignName}
                onChange={(e) => setNewSignName(e.target.value)}
                placeholder="e.g. Please, Sorry, Letter K"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Curriculum Category
              </label>
              <select
                value={newSignCategory}
                onChange={(e) => setNewSignCategory(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
              >
                <option value="words">Words & Phrases</option>
                <option value="letters">Letters</option>
                <option value="numbers">Numbers</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Description / Finger Instructions
              </label>
              <textarea
                rows={3}
                value={newSignDesc}
                onChange={(e) => setNewSignDesc(e.target.value)}
                placeholder="Describe how the hand is formed and oriented..."
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
            >
              Add Gesture
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
