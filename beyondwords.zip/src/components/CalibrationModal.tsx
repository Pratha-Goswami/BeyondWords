import React, { useState } from 'react';
import { X, CheckCircle2, Sliders, RefreshCw, Hand, Sparkles } from 'lucide-react';
import { LandmarkPoint } from '../types';
import { calculateDistance } from '../services/gestureClassifier';
import { calibrationService, UserCalibrationProfile } from '../services/calibrationService';

interface CalibrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLandmarks: LandmarkPoint[] | null;
  onCalibrationSaved?: () => void;
}

export const CalibrationModal: React.FC<CalibrationModalProps> = ({
  isOpen,
  onClose,
  currentLandmarks,
  onCalibrationSaved,
}) => {
  const [step, setStep] = useState(1);
  const [samples, setSamples] = useState<{
    palmScale: number;
    totalHandLength: number;
    proportions: { thumb: number; index: number; middle: number; ring: number; pinky: number };
  }[]>([]);
  const [isFinished, setIsFinished] = useState(false);
  const [currentProfile, setCurrentProfile] = useState<UserCalibrationProfile>(() =>
    calibrationService.getProfile()
  );

  if (!isOpen) return null;

  const captureSample = () => {
    if (!currentLandmarks || currentLandmarks.length < 21) return;

    const wrist = currentLandmarks[0];
    const palm = calculateDistance(wrist, currentLandmarks[9]);
    const totalLen = calculateDistance(wrist, currentLandmarks[12]);

    const thumb = calculateDistance(currentLandmarks[4], currentLandmarks[2]) / palm;
    const index = calculateDistance(currentLandmarks[8], currentLandmarks[5]) / palm;
    const middle = calculateDistance(currentLandmarks[12], currentLandmarks[9]) / palm;
    const ring = calculateDistance(currentLandmarks[16], currentLandmarks[13]) / palm;
    const pinky = calculateDistance(currentLandmarks[20], currentLandmarks[17]) / palm;

    const newSample = {
      palmScale: palm,
      totalHandLength: totalLen,
      proportions: { thumb, index, middle, ring, pinky },
    };

    const nextSamples = [...samples, newSample];
    setSamples(nextSamples);

    if (nextSamples.length >= 5) {
      // Calculate averages across 5 captures
      const avgPalm = nextSamples.reduce((a, b) => a + b.palmScale, 0) / 5;
      const avgLen = nextSamples.reduce((a, b) => a + b.totalHandLength, 0) / 5;
      const avgThumb = nextSamples.reduce((a, b) => a + b.proportions.thumb, 0) / 5;
      const avgIndex = nextSamples.reduce((a, b) => a + b.proportions.index, 0) / 5;
      const avgMiddle = nextSamples.reduce((a, b) => a + b.proportions.middle, 0) / 5;
      const avgRing = nextSamples.reduce((a, b) => a + b.proportions.ring, 0) / 5;
      const avgPinky = nextSamples.reduce((a, b) => a + b.proportions.pinky, 0) / 5;

      const saved = calibrationService.saveProfile({
        palmScale: Math.round(avgPalm * 1000) / 1000,
        totalHandLength: Math.round(avgLen * 1000) / 1000,
        fingerProportions: {
          thumb: Math.round(avgThumb * 100) / 100,
          index: Math.round(avgIndex * 100) / 100,
          middle: Math.round(avgMiddle * 100) / 100,
          ring: Math.round(avgRing * 100) / 100,
          pinky: Math.round(avgPinky * 100) / 100,
        },
        preferredDistance: avgPalm > 0.3 ? 'close' : avgPalm < 0.16 ? 'far' : 'optimal',
      });

      setCurrentProfile(saved);
      setIsFinished(true);
      if (onCalibrationSaved) onCalibrationSaved();
    } else {
      setStep(nextSamples.length + 1);
    }
  };

  const handleReset = () => {
    const defaultProf = calibrationService.resetProfile();
    setCurrentProfile(defaultProf);
    setSamples([]);
    setStep(1);
    setIsFinished(false);
    if (onCalibrationSaved) onCalibrationSaved();
  };

  const hasHand = Boolean(currentLandmarks && currentLandmarks.length >= 21);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Hand Calibration & Tuning</h3>
              <p className="text-xs text-slate-500">Learns your specific hand proportions & distance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!isFinished ? (
          <div className="mt-5 space-y-5">
            {/* Step progress pills */}
            <div className="flex items-center justify-between gap-1.5">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className={`flex-1 h-2 rounded-full transition-all ${
                    i < step
                      ? 'bg-emerald-500'
                      : i === step
                      ? 'bg-blue-600 animate-pulse'
                      : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-center">
              <div className="inline-flex p-3 rounded-2xl bg-white shadow-xs mb-2">
                <Hand className={`w-8 h-8 ${hasHand ? 'text-blue-600 animate-pulse' : 'text-slate-400'}`} />
              </div>
              <h4 className="text-sm font-bold text-slate-900">
                Sample {step} of 5: {step === 1 ? 'Show Open Palm (Sign 5)' : step === 3 ? 'Relax Hand Slightly' : 'Hold Hand Steady'}
              </h4>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Keep your hand in the center of the camera. The system will measure palm scale, finger lengths, and baseline depth.
              </p>

              <div className="mt-4 flex items-center justify-center gap-2">
                <span
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
                    hasHand
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-100 text-amber-800 border border-amber-300'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${hasHand ? 'bg-emerald-500' : 'bg-amber-500 animate-ping'}`}
                  />
                  {hasHand ? 'Live Hand Tracked' : 'Position Hand in Camera'}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={captureSample}
                disabled={!hasHand}
                className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none rounded-xl transition-all shadow-xs flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Capture Sample {step}/5
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-5 space-y-4">
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-center">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
              <h4 className="text-sm font-bold text-emerald-900">Calibration Complete!</h4>
              <p className="text-xs text-emerald-700 mt-0.5">
                Your personal biometric hand profile has been saved.
              </p>
            </div>

            {/* Metric summaries */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 block">Palm Scale</span>
                <span className="font-bold text-slate-800 font-mono text-sm">
                  {currentProfile.palmScale}
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 block">Total Hand Length</span>
                <span className="font-bold text-slate-800 font-mono text-sm">
                  {currentProfile.totalHandLength}
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 block">Index Ratio</span>
                <span className="font-bold text-slate-800 font-mono text-sm">
                  {currentProfile.fingerProportions.index}x
                </span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-500 block">Distance Baseline</span>
                <span className="font-bold text-slate-800 capitalize">
                  {currentProfile.preferredDistance}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reset to Default
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
