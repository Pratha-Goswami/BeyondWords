import React, { useEffect, useState, useRef } from 'react';
import confetti from 'canvas-confetti';
import { CheckCircle2, XCircle, ArrowRight, RotateCcw, Volume2 } from 'lucide-react';
import { GestureDefinition } from '../types';
import { HandGuideGraphic } from './HandGuideGraphic';
import { audioService } from '../services/audioService';

interface CelebrationFeedbackProps {
  status: 'correct' | 'incorrect' | null;
  targetGesture: GestureDefinition;
  accuracy: number;
  detectedSign: string;
  mistakeText?: string;
  tipText?: string;
  onNextLesson?: () => void;
  onRetry?: () => void;
  onClose?: () => void;
  earnedXP?: number;
  autoAdvance?: boolean;
}

const SUCCESS_HEADINGS = [
  '✅ Perfect!',
  '✅ Great Job!',
  '✅ Excellent Gesture!',
  '✅ You Got It Correct!',
];

export const CelebrationFeedback: React.FC<CelebrationFeedbackProps> = ({
  status,
  targetGesture,
  accuracy,
  detectedSign,
  mistakeText,
  tipText,
  onNextLesson,
  onRetry,
  onClose,
  earnedXP = 25,
  autoAdvance = false,
}) => {
  const [countdown, setCountdown] = useState<number | null>(null);
  const onNextLessonRef = useRef(onNextLesson);
  onNextLessonRef.current = onNextLesson;

  const previousStatusRef = useRef<string | null>(null);

  useEffect(() => {
    // Only fire effects when status actually changes (e.g. null -> 'correct')
    if (status && status !== previousStatusRef.current) {
      previousStatusRef.current = status;

      if (status === 'correct') {
        audioService.playSuccess();

        // Announce the result aloud
        const spokenResult = `Correct! Sign ${targetGesture.name} identified with ${accuracy} percent accuracy. Excellent job!`;
        audioService.speakInstruction(spokenResult);

        // Confetti burst
        const count = 180;
        const defaults = {
          origin: { y: 0.7 },
          colors: ['#2563EB', '#14B8A6', '#10B981', '#F59E0B', '#EC4899'],
        };

        confetti({
          ...defaults,
          spread: 70,
          particleCount: count,
        });

        if (autoAdvance) {
          setCountdown(4);
        }
      } else if (status === 'incorrect') {
        audioService.playRetry();
        const advice = tipText || mistakeText || 'Please adjust your fingers.';
        audioService.speakInstruction(`Finger position incorrect. Try: ${advice}`);
        setCountdown(null);
      }
    } else if (!status) {
      previousStatusRef.current = null;
      setCountdown(null);
    }
  }, [status, targetGesture.name, accuracy, tipText, mistakeText, autoAdvance]);

  // Countdown timer for auto-advance
  useEffect(() => {
    if (countdown === null || countdown <= 0) return;
    const timer = setTimeout(() => {
      if (countdown === 1) {
        onNextLessonRef.current?.();
      } else {
        setCountdown(countdown - 1);
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [countdown]);

  if (!status) return null;

  const randomSuccessTitle =
    SUCCESS_HEADINGS[Math.floor(Math.random() * SUCCESS_HEADINGS.length)];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`w-full max-w-lg p-6 rounded-3xl shadow-2xl border transition-all ${
          status === 'correct'
            ? 'bg-gradient-to-b from-emerald-50 via-white to-teal-50/40 border-emerald-300'
            : 'bg-gradient-to-b from-rose-50 via-white to-amber-50/40 border-rose-300'
        }`}
      >
        {/* Status Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`p-3 rounded-2xl ${
                status === 'correct'
                  ? 'bg-emerald-100 text-emerald-600'
                  : 'bg-rose-100 text-rose-600'
              }`}
            >
              {status === 'correct' ? (
                <CheckCircle2 className="w-8 h-8 animate-bounce" />
              ) : (
                <XCircle className="w-8 h-8" />
              )}
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">
                {status === 'correct' ? randomSuccessTitle : '❌ Finger position incorrect'}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Target Sign: <span className="font-semibold text-slate-800">{targetGesture.name}</span>
                {' · '}
                Detected: <span className="font-semibold text-slate-800">{detectedSign}</span>
                {' · '}
                Match:{' '}
                <span className="font-mono font-bold text-slate-900 tabular-nums">
                  {accuracy}%
                </span>
              </p>
            </div>
          </div>

          {status === 'correct' && (
            <div className="px-3 py-1.5 bg-amber-100 border border-amber-300 rounded-xl text-xs font-bold text-amber-800 flex items-center gap-1">
              <span>+{earnedXP} XP</span>
              <span className="text-amber-500">✨</span>
            </div>
          )}
        </div>

        {/* Content details based on status */}
        {status === 'correct' ? (
          <div className="mt-5 space-y-4">
            <div className="p-4 bg-white/80 rounded-2xl border border-emerald-100 text-sm text-slate-700">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-emerald-900">
                  AI automatically confirmed: Gesture "{targetGesture.name}" verified!
                </p>
                <button
                  onClick={() =>
                    audioService.speakInstruction(
                      `Sign ${targetGesture.name} verified with ${accuracy} percent accuracy.`
                    )
                  }
                  className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
                  title="Re-play voice announcement"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {targetGesture.shortDesc}
              </p>
            </div>

            {targetGesture.culturalNote && (
              <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl text-xs text-blue-900">
                <span className="font-semibold">Cultural Tip:</span> {targetGesture.culturalNote}
              </div>
            )}
          </div>
        ) : (
          <div className="mt-5 space-y-4">
            {/* Mistake & Correction Advice */}
            <div className="p-4 bg-rose-50/60 rounded-2xl border border-rose-100">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-rose-800 uppercase tracking-wide">
                  Correction Needed
                </p>
                <button
                  onClick={() =>
                    audioService.speakInstruction(
                      `Try: ${tipText || mistakeText || 'adjust your hand'}`
                    )
                  }
                  className="p-1 text-rose-700 hover:bg-rose-100 rounded-md transition-colors"
                  title="Voice guide"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-sm font-semibold text-slate-800 mt-1">
                {mistakeText || 'Adjustment required on finger extension.'}
              </p>
              {tipText && (
                <p className="text-xs text-slate-600 mt-2 flex items-start gap-1">
                  <span className="font-bold text-blue-600">Try:</span> {tipText}
                </p>
              )}
            </div>

            {/* Side-by-Side Comparison: User vs Target */}
            <div>
              <p className="text-xs font-semibold text-slate-700 mb-2">
                Side-by-Side Comparison:
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-white rounded-xl border border-slate-200 text-center">
                  <span className="text-[11px] font-medium text-slate-500 block mb-1">
                    Your Attempt
                  </span>
                  <div className="h-28 flex flex-col items-center justify-center bg-slate-50 rounded-lg border border-dashed border-slate-300">
                    <span className="text-2xl font-bold text-rose-600">{detectedSign}</span>
                    <span className="text-[11px] text-slate-500 mt-1">{accuracy}% match</span>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-xl border border-emerald-200 text-center">
                  <span className="text-[11px] font-medium text-emerald-700 block mb-1">
                    Target: {targetGesture.name}
                  </span>
                  <div className="h-28 flex flex-col items-center justify-center bg-emerald-50/50 rounded-lg border border-emerald-200 overflow-hidden">
                    <HandGuideGraphic gesture={targetGesture} size={110} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons & Countdown */}
        <div className="mt-6 flex items-center justify-between pt-4 border-t border-slate-100">
          <div>
            {countdown !== null && (
              <span className="text-xs text-emerald-700 font-medium animate-pulse">
                Auto-advancing in {countdown}s...
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            {status === 'incorrect' ? (
              <>
                {onClose && (
                  <button
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 transition-colors"
                  >
                    Dismiss
                  </button>
                )}
                {onRetry && (
                  <button
                    onClick={onRetry}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Try Again
                  </button>
                )}
              </>
            ) : (
              <>
                {onClose && (
                  <button
                    onClick={() => {
                      setCountdown(null);
                      onClose();
                    }}
                    className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 transition-colors"
                  >
                    Practice Again
                  </button>
                )}
                {onNextLesson && (
                  <button
                    onClick={() => {
                      setCountdown(null);
                      onNextLessonRef.current?.();
                    }}
                    className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
                  >
                    <span>Next Lesson</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
