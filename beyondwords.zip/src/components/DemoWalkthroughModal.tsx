import React from 'react';
import { X, Play, Camera, CheckCircle2, Sparkles, ArrowRight } from 'lucide-react';

interface DemoWalkthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartLearning: () => void;
}

export const DemoWalkthroughModal: React.FC<DemoWalkthroughModalProps> = ({
  isOpen,
  onClose,
  onStartLearning,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2.5 py-1 rounded-md">
            Product Walkthrough
          </span>
          <h2 className="text-2xl font-black text-slate-900 mt-2">
            How BeyondWords AI Coaching Works
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Experience our 4-step intelligent sign language loop designed for rapid muscle memory.
          </p>
        </div>

        {/* 4 Interactive Flow Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs mb-2">
              1
            </div>
            <h3 className="text-xs font-bold text-slate-900">1. Target Sign Blueprint</h3>
            <p className="text-[11px] text-slate-600 mt-1 leading-normal">
              Explore step-by-step formation guides, hand orientation, and 21 anatomical landmark nodes.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-xs mb-2">
              2
            </div>
            <h3 className="text-xs font-bold text-slate-900">2. Live Webcam AI Tracking</h3>
            <p className="text-[11px] text-slate-600 mt-1 leading-normal">
              MediaPipe extracts finger joints in real-time right in your browser with zero latency.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs mb-2">
              3
            </div>
            <h3 className="text-xs font-bold text-slate-900">3. Instant Celebratory Feedback</h3>
            <p className="text-[11px] text-slate-600 mt-1 leading-normal">
              Correct gestures trigger pleasant chimes, confetti bursts, XP gains, and streak points.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-xs mb-2">
              4
            </div>
            <h3 className="text-xs font-bold text-slate-900">4. AI Doubt Solver Assistant</h3>
            <p className="text-[11px] text-slate-600 mt-1 leading-normal">
              Ask "BeyondWords Guide" anytime you encounter finger stiffness or need placement tips.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 transition-colors"
          >
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onStartLearning();
            }}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
          >
            <span>Launch Live Lesson Now</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
