import React from 'react';
import {
  Flame,
  Award,
  Zap,
  TrendingUp,
  Target,
  CheckCircle,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { storageService, BADGE_DEFINITIONS } from '../services/storageService';
import { GESTURES } from '../data/gestures';

export const GamificationDashboard: React.FC = () => {
  const user = storageService.getUserProgress();

  // Calculate stats
  const totalCompleted = user.completedLessons.length;
  const totalGestures = GESTURES.length;
  const completionPercentage = Math.round((totalCompleted / totalGestures) * 100);

  const masteryScores = Object.values(user.gestureMastery);
  const avgAccuracy =
    masteryScores.length > 0
      ? Math.round(masteryScores.reduce((a, b) => a + b, 0) / masteryScores.length)
      : 92;

  // Level thresholds
  const levelLimits = {
    Beginner: { next: 'Explorer', cap: 200 },
    Explorer: { next: 'Communicator', cap: 500 },
    Communicator: { next: 'Expert Signer', cap: 1000 },
    'Expert Signer': { next: 'Mastery', cap: 2000 },
  };

  const currentLevelInfo = levelLimits[user.level] || levelLimits['Beginner'];
  const progressToNextLevel = Math.min(100, Math.round((user.xp / currentLevelInfo.cap) * 100));

  // Mock weekly active data points
  const weeklyDays = [
    { day: 'Mon', xp: 45, height: '45%' },
    { day: 'Tue', xp: 70, height: '70%' },
    { day: 'Wed', xp: 30, height: '30%' },
    { day: 'Thu', xp: 90, height: '90%' },
    { day: 'Fri', xp: 60, height: '60%' },
    { day: 'Sat', xp: 85, height: '85%' },
    { day: 'Sun', xp: 110, height: '100%' },
  ];

  // Skill radar metrics
  const skillMetrics = [
    { label: 'Alphabet Precision', score: 94 },
    { label: 'Number Speed', score: 90 },
    { label: 'Facial Expression', score: 85 },
    { label: 'Hand Stability', score: 96 },
    { label: 'Everyday Vocabulary', score: 88 },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner: User Profile, Level & XP */}
      <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-teal-600 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur border border-white/30 flex items-center justify-center text-2xl font-bold">
              {user.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black">{user.name}</h1>
                <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-teal-400/30 text-teal-100 border border-teal-300/40">
                  {user.level}
                </span>
              </div>
              <p className="text-xs text-blue-100 mt-1">
                Active Streak: <span className="font-bold text-amber-300">{user.streakDays} Days</span>
                {' · '}
                Member since October 2026
              </p>
            </div>
          </div>

          {/* Quick Metrics Strip */}
          <div className="flex items-center gap-4 sm:gap-6 bg-white/10 backdrop-blur rounded-2xl p-4 border border-white/20">
            <div className="text-center">
              <span className="text-[11px] text-blue-200 uppercase tracking-wider block">Total XP</span>
              <span className="text-xl sm:text-2xl font-black font-mono tabular-nums text-white">
                {user.xp}
              </span>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center">
              <span className="text-[11px] text-blue-200 uppercase tracking-wider block">Lessons</span>
              <span className="text-xl sm:text-2xl font-black font-mono tabular-nums text-teal-200">
                {totalCompleted}/{totalGestures}
              </span>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center">
              <span className="text-[11px] text-blue-200 uppercase tracking-wider block">Accuracy</span>
              <span className="text-xl sm:text-2xl font-black font-mono tabular-nums text-emerald-300">
                {avgAccuracy}%
              </span>
            </div>
          </div>
        </div>

        {/* Level Progression Bar */}
        <div className="mt-6 pt-5 border-t border-white/20 relative z-10">
          <div className="flex justify-between text-xs text-blue-100 mb-2">
            <span>
              Level Progress: <strong>{user.level}</strong>
            </span>
            <span>
              {user.xp} / {currentLevelInfo.cap} XP to <strong>{currentLevelInfo.next}</strong>
            </span>
          </div>
          <div className="w-full h-3 bg-black/20 rounded-full overflow-hidden p-0.5">
            <div
              className="h-full bg-gradient-to-r from-teal-300 to-amber-300 rounded-full transition-all duration-500"
              style={{ width: `${progressToNextLevel}%` }}
            />
          </div>
        </div>
      </div>

      {/* Grid: 4 Core Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Flame className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-medium">Daily Streak</span>
            <p className="text-xl font-extrabold text-slate-900">{user.streakDays} Days Strong</p>
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-medium">Curriculum Progress</span>
            <p className="text-xl font-extrabold text-slate-900">{completionPercentage}% Completed</p>
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-medium">Average Precision</span>
            <p className="text-xl font-extrabold text-slate-900">{avgAccuracy}% Landmark Match</p>
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-500 font-medium">Quiz High Score</span>
            <p className="text-xl font-extrabold text-slate-900">
              {user.quizScores.length > 0
                ? Math.max(...user.quizScores.map((q) => q.score))
                : 90}{' '}
              pts
            </p>
          </div>
        </div>
      </div>

      {/* Analytics & Weekly Progress Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Weekly Progress Graph (Col 1-7) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-base font-bold text-slate-900">Weekly Practice Activity</h2>
              <p className="text-xs text-slate-500">XP points earned per day this week</p>
            </div>
            <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-md">
              Past 7 Days
            </span>
          </div>

          <div className="h-56 flex items-end justify-between gap-3 pt-6 px-2 border-b border-slate-100">
            {weeklyDays.map((d, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <span className="text-[10px] font-mono font-semibold text-slate-400 group-hover:text-blue-600 transition-colors">
                  {d.xp}xp
                </span>
                <div className="w-full max-w-[36px] bg-slate-100 rounded-t-lg overflow-hidden flex items-end h-full">
                  <div
                    className="w-full bg-gradient-to-t from-blue-600 to-teal-500 rounded-t-lg transition-all group-hover:brightness-110"
                    style={{ height: d.height }}
                  />
                </div>
                <span className="text-xs font-medium text-slate-600 mt-1">{d.day}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
            <span>Daily Goal: 50 XP</span>
            <span className="font-semibold text-emerald-600">Goal Achieved 5/7 Days</span>
          </div>
        </div>

        {/* Skill Radar / Competency Matrix (Col 8-12) */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Skill Competency Breakdown</h2>
            <Sparkles className="w-4 h-4 text-teal-600" />
          </div>

          <div className="space-y-4">
            {skillMetrics.map((skill, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-700">{skill.label}</span>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">
                    {skill.score}%
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-teal-400 rounded-full"
                    style={{ width: `${skill.score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 leading-relaxed">
            <strong className="text-slate-800">Coach Insight:</strong> Your alphabet precision and hand stability are top-tier! Focus on everyday conversational signs like "Thank You" and "Help" next.
          </div>
        </div>
      </div>

      {/* Achievement Badges Section */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Achievement Badges</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Unlock milestones as you build fluency and master signs
            </p>
          </div>
          <span className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            {user.unlockedBadges.length} / {Object.keys(BADGE_DEFINITIONS).length} Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(BADGE_DEFINITIONS).map(([key, badge]) => {
            const isUnlocked = user.unlockedBadges.includes(key);

            return (
              <div
                key={key}
                className={`p-4 rounded-2xl border transition-all ${
                  isUnlocked
                    ? 'bg-gradient-to-b from-teal-50/50 to-white border-teal-200 shadow-xs'
                    : 'bg-slate-50/60 border-slate-200 opacity-60'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="text-3xl p-2 bg-white rounded-xl shadow-xs border border-slate-100 shrink-0">
                    {badge.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-bold text-slate-900">{badge.title}</h3>
                      {isUnlocked && <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />}
                    </div>
                    <p className="text-xs text-slate-500 mt-1 leading-normal">{badge.desc}</p>
                    <span
                      className={`inline-block mt-2 text-[10px] font-semibold uppercase tracking-wider ${
                        isUnlocked ? 'text-teal-700' : 'text-slate-400'
                      }`}
                    >
                      {isUnlocked ? 'Unlocked' : 'In Progress'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Gesture Mastery Grid */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-slate-900">20 Gestures Mastery Index</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-10 gap-2.5">
          {GESTURES.map((g) => {
            const score = user.gestureMastery[g.id] || 0;
            const isLearned = user.completedLessons.includes(g.id);

            return (
              <div
                key={g.id}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  isLearned
                    ? 'bg-emerald-50/50 border-emerald-200 text-slate-900'
                    : 'bg-slate-50 border-slate-200 text-slate-400'
                }`}
              >
                <span className="text-base font-bold block">{g.name}</span>
                <span className="text-[10px] font-mono block mt-0.5 text-slate-500">
                  {score > 0 ? `${score}%` : 'Unpracticed'}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
