import React from 'react';
import { GestureDefinition } from '../types';
import { getSyntheticLandmarksForSign, HAND_CONNECTIONS, FINGER_LANDMARKS, FingerAccuracyStatus } from '../services/gestureClassifier';

interface HandGuideGraphicProps {
  gesture: GestureDefinition;
  size?: number;
  highlightMistake?: string;
  showLandmarks?: boolean;
  fingerAccuracy?: FingerAccuracyStatus;
}

export const HandGuideGraphic: React.FC<HandGuideGraphicProps> = ({
  gesture,
  size = 280,
  highlightMistake,
  showLandmarks = true,
  fingerAccuracy,
}) => {
  const landmarks = getSyntheticLandmarksForSign(gesture.id);

  // SVG coordinate transform: map [0, 1] normalized landmarks to SVG viewBox [0, size]
  const svgWidth = size;
  const svgHeight = size;
  const padding = 24;
  const innerW = svgWidth - padding * 2;
  const innerH = svgHeight - padding * 2;

  const toSvgX = (x: number) => padding + x * innerW;
  const toSvgY = (y: number) => padding + (y - 0.25) * (innerH / 0.7);

  return (
    <div className="relative flex flex-col items-center justify-center p-4 bg-slate-900/5 rounded-2xl border border-slate-200">
      {/* Target Badge */}
      <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 bg-white/90 backdrop-blur rounded-md border border-slate-200 shadow-xs">
        <span className="text-xs font-semibold text-blue-600">Target Blueprint</span>
        <span className="text-xs text-slate-400">·</span>
        <span className="text-xs font-bold text-slate-800">{gesture.name}</span>
      </div>

      <svg
        width={svgWidth}
        height={svgHeight}
        viewBox={`0 0 ${svgWidth} ${svgHeight}`}
        className="drop-shadow-sm select-none"
        aria-label={`Hand guide for sign ${gesture.name}`}
      >
        <defs>
          <linearGradient id="boneGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#2563EB" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#14B8A6" stopOpacity="0.8" />
          </linearGradient>
          <radialGradient id="nodeGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#14B8A6" stopOpacity="1" />
            <stop offset="100%" stopColor="#0D9488" stopOpacity="0.7" />
          </radialGradient>
        </defs>

        {/* Subtle Palm Silhouette / Aura */}
        <circle
          cx={toSvgX(landmarks[9].x)}
          cy={toSvgY(landmarks[9].y + 0.08)}
          r={svgWidth * 0.24}
          fill="#3B82F6"
          fillOpacity="0.08"
          stroke="#3B82F6"
          strokeOpacity="0.15"
          strokeWidth="1.5"
          strokeDasharray="4 4"
        />

        {/* Hand Landmark Bone Connections */}
        {showLandmarks &&
          HAND_CONNECTIONS.map(([startIdx, endIdx], i) => {
            const p1 = landmarks[startIdx];
            const p2 = landmarks[endIdx];
            return (
              <line
                key={`bone-${i}`}
                x1={toSvgX(p1.x)}
                y1={toSvgY(p1.y)}
                x2={toSvgX(p2.x)}
                y2={toSvgY(p2.y)}
                stroke="url(#boneGrad)"
                strokeWidth={startIdx === 0 ? 3.5 : 2.5}
                strokeLinecap="round"
              />
            );
          })}

        {/* Hand Landmark Nodes (21 points) */}
        {showLandmarks &&
          landmarks.map((pt, idx) => {
            const isFingertip = [4, 8, 12, 16, 20].includes(idx);
            const isWrist = idx === 0;

            // Check finger accuracy if provided
            let isFingerCorrect = true;
            if (fingerAccuracy) {
              if (FINGER_LANDMARKS.thumb.includes(idx)) isFingerCorrect = fingerAccuracy.thumb;
              else if (FINGER_LANDMARKS.index.includes(idx)) isFingerCorrect = fingerAccuracy.index;
              else if (FINGER_LANDMARKS.middle.includes(idx)) isFingerCorrect = fingerAccuracy.middle;
              else if (FINGER_LANDMARKS.ring.includes(idx)) isFingerCorrect = fingerAccuracy.ring;
              else if (FINGER_LANDMARKS.pinky.includes(idx)) isFingerCorrect = fingerAccuracy.pinky;
            }

            const fillCol = isWrist
              ? '#1E293B'
              : fingerAccuracy
              ? isFingerCorrect
                ? '#10B981'
                : '#EF4444'
              : isFingertip
              ? '#2563EB'
              : 'url(#nodeGlow)';

            return (
              <g key={`pt-${idx}`}>
                <circle
                  cx={toSvgX(pt.x)}
                  cy={toSvgY(pt.y)}
                  r={isFingertip ? 5.5 : isWrist ? 6 : 3.5}
                  fill={fillCol}
                  stroke="#FFFFFF"
                  strokeWidth="1.5"
                />
                {isFingertip && (
                  <circle
                    cx={toSvgX(pt.x)}
                    cy={toSvgY(pt.y)}
                    r={9}
                    fill="none"
                    stroke={fingerAccuracy ? (isFingerCorrect ? '#10B981' : '#EF4444') : '#2563EB'}
                    strokeWidth="1"
                    strokeOpacity="0.5"
                    className="animate-pulse"
                  />
                )}
              </g>
            );
          })}

        {/* Tip labels for key landmarks */}
        <text
          x={toSvgX(landmarks[8].x)}
          y={toSvgY(landmarks[8].y) - 10}
          textAnchor="middle"
          className="text-[10px] font-semibold fill-slate-700"
        >
          Index
        </text>
        <text
          x={toSvgX(landmarks[4].x) - 12}
          y={toSvgY(landmarks[4].y)}
          textAnchor="middle"
          className="text-[10px] font-semibold fill-slate-700"
        >
          Thumb
        </text>
      </svg>

      {/* Guide text bar */}
      <div className="mt-2 text-center max-w-xs">
        <p className="text-xs font-medium text-slate-700">{gesture.fingerStateDescription}</p>
        {highlightMistake && (
          <p className="mt-1 text-[11px] text-amber-700 font-medium bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
            ⚠️ {highlightMistake}
          </p>
        )}
      </div>
    </div>
  );
};
