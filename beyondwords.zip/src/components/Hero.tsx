import React from 'react';
import { ArrowRight, Play, Sparkles, CheckCircle2 } from 'lucide-react';

interface HeroProps {
  onStartLearning: () => void;
  onWatchDemo: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStartLearning, onWatchDemo }) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:py-20 bg-gradient-to-b from-blue-50/50 via-white to-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text & CTA Column (Col 1-7) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-700 bg-blue-100/70 border border-blue-200/60 px-3 py-1.5 rounded-full">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>AI-Powered Sign Language Practice Coach</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.1] text-balance">
              Breaking Communication Barriers Through{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-500">
                Sign Language
              </span>{' '}
              Learning
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl text-balance">
              BeyondWords empowers hearing individuals to learn American Sign Language with real-time
              webcam hand tracking, instant AI landmark feedback, and an intelligent doubt-solving coach.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onStartLearning}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-2xl transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5"
              >
                <span>Start Learning</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onWatchDemo}
                className="inline-flex items-center gap-2 px-5 py-3.5 text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-2xl transition-all shadow-2xs"
              >
                <Play className="w-4 h-4 text-blue-600 fill-blue-600" />
                <span>Watch Demo</span>
              </button>
            </div>

            {/* Trust Markers */}
            <div className="pt-6 border-t border-slate-200/80 flex flex-wrap items-center gap-6 text-xs text-slate-500">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span>MediaPipe 21-Landmark Vision</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span>20 Core Signs & Numbers</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600" />
                <span>Zero Latency Local Feedback</span>
              </div>
            </div>
          </div>

          {/* Right Visual Stage Column (Col 8-12) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none rounded-3xl overflow-hidden shadow-2xl border border-slate-200 bg-slate-900 group">
              <img
                src="/src/assets/images/hero_asl_coach_1793593867984.jpg"
                alt="ASL instructor smiling and demonstrating an ASL hand gesture"
                className="w-full h-auto object-cover group-hover:scale-102 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />

              {/* Floating Live Badge */}
              <div className="absolute top-4 left-4 p-2.5 bg-slate-900/80 backdrop-blur rounded-xl border border-white/20 text-white flex items-center gap-2 shadow-lg">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-bold">Live AI Vision Coach</span>
              </div>

              {/* Floating Accuracy Tag */}
              <div className="absolute bottom-4 right-4 p-3 bg-white/95 backdrop-blur rounded-2xl border border-slate-200 text-slate-900 shadow-xl flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold text-sm">
                  96%
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                    Model Accuracy
                  </span>
                  <span className="text-xs font-bold text-slate-800">Gesture "A" Verified</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
