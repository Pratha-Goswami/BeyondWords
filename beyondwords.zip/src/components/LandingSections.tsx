import React, { useState } from 'react';
import {
  Camera,
  CheckCircle2,
  Users,
  Brain,
  Award,
  Zap,
  Globe2,
  HeartHandshake,
  Mail,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  Send,
} from 'lucide-react';

interface LandingSectionsProps {
  onStartLearning: () => void;
}

export const LandingSections: React.FC<LandingSectionsProps> = ({ onStartLearning }) => {
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSubmitted(true);
    setContactName('');
    setContactEmail('');
    setContactMessage('');
    setTimeout(() => setContactSubmitted(false), 4000);
  };

  return (
    <div className="space-y-24 py-12">
      {/* 1. WHY SIGN LANGUAGE MATTERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Human Connection First
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-3 text-balance">
            Why Learning Sign Language Changes Everything
          </h2>
          <p className="text-base text-slate-600 mt-3 text-balance">
            Over 70 million deaf individuals worldwide use sign language as their primary mother tongue.
            Bridging this communication divide fosters authentic inclusion in schools, workplaces, and daily life.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-8 bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-5">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Empathy & Inclusion</h3>
            <p className="text-xs text-slate-600 leading-relaxed mt-2">
              Knowing even basic greetings and fingerspelling signals immediate respect and welcome to deaf and hard-of-hearing colleagues, neighbors, and friends.
            </p>
          </div>

          <div className="p-8 bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-teal-300 transition-all">
            <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mb-5">
              <Brain className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Cognitive & Spatial Mastery</h3>
            <p className="text-xs text-slate-600 leading-relaxed mt-2">
              ASL activates 3D spatial reasoning, fine motor dexterity, and facial communicative acuity that standard spoken languages cannot provide.
            </p>
          </div>

          <div className="p-8 bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-5">
              <Globe2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Universal Communication</h3>
            <p className="text-xs text-slate-600 leading-relaxed mt-2">
              From noisy public venues to quiet libraries and underwater sports, sign language provides a robust, expressive channel when speech fails.
            </p>
          </div>
        </div>
      </section>

      {/* 2. ABOUT DEAF COMMUNICATION (CULTURAL RESPECT & VISUAL GRAMMAR) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-blue-950 rounded-3xl p-8 sm:p-12 text-white shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <span className="text-xs font-bold text-teal-400 uppercase tracking-wider">
                Deaf Culture & Etiquette
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-balance">
                ASL Is a Rich, Natural Language — Not Just Hand Waves
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                American Sign Language possesses its own nuanced syntax, grammar, idioms, and visual poetry. Eye contact is vital, and facial expressions—like raised eyebrows for yes/no questions—form the grammatical structure of the sentence.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-3.5 bg-white/10 rounded-xl border border-white/15">
                  <span className="text-xs font-bold text-teal-300 block mb-0.5">Maintain Eye Contact</span>
                  <span className="text-[11px] text-slate-300 leading-tight block">
                    Looking away while someone signs is equivalent to walking away mid-sentence.
                  </span>
                </div>
                <div className="p-3.5 bg-white/10 rounded-xl border border-white/15">
                  <span className="text-xs font-bold text-teal-300 block mb-0.5">Facial Grammar Matters</span>
                  <span className="text-[11px] text-slate-300 leading-tight block">
                    Your head tilt, brow expression, and mouth shape determine tense and tone.
                  </span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 flex justify-center">
              <div className="p-6 bg-white/10 backdrop-blur rounded-2xl border border-white/20 text-center space-y-3 max-w-xs">
                <span className="text-4xl">🤟</span>
                <h3 className="text-base font-bold text-white">The "I Love You" Sign</h3>
                <p className="text-xs text-slate-300">
                  Combining letters I, L, and Y into one universal handshape recognized globally.
                </p>
                <button
                  onClick={onStartLearning}
                  className="w-full py-2 px-4 text-xs font-bold text-slate-900 bg-white hover:bg-teal-50 rounded-xl transition-colors shadow-xs"
                >
                  Practice Core Signs
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. CORE FEATURES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Platform Architecture
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-3 text-balance">
            Built for Real-Time Feedback and Fluency
          </h2>
          <p className="text-base text-slate-600 mt-3 text-balance">
            Everything you need to go from complete beginner to confident signer in weeks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Webcam Vision Tracking</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Live MediaPipe 21-landmark tracking detects fingers, joints, and orientation without special gloves.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Instant AI Mistake Detection</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Provides specific corrections (e.g. "Raise index finger slightly") instead of generic errors.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Gamified Progression</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Earn XP points, unlock milestone badges, maintain daily streaks, and rank up from Beginner to Expert.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Brain className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">BeyondWords Guide AI</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              An intelligent chatbot assistant that answers questions about sign origins, finger stiffness, and tips.
            </p>
          </div>
        </div>
      </section>

      {/* 4. AI RECOGNITION SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 rounded-3xl overflow-hidden shadow-xl border border-slate-200 bg-slate-900">
            <img
              src="/src/assets/images/ai_hand_tracking_demo_1793593868641.jpg"
              alt="AI hand landmark node overlays in teal and blue tracking sign language"
              className="w-full h-auto object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-600 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
              Computer Vision & AI
            </span>
            <h2 className="text-3xl font-extrabold text-slate-900 text-balance">
              Precision Hand Tracking with 21 Biometric Landmark Nodes
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              BeyondWords captures wrist, MCP, PIP, DIP, and fingertip nodes at 30 frames per second. Our geometric classifier evaluates curvature, relative bone distances, and finger extension ratios with up to 96% verification accuracy.
            </p>

            <div className="space-y-3 text-xs text-slate-700">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Distinguishes left and right hands seamlessly</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Scale-invariant normalization for any camera distance</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Local client evaluation for absolute privacy (video never leaves your device)</span>
              </div>
            </div>

            <button
              onClick={onStartLearning}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
            >
              <span>Test AI Detection Live</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 5. HACKATHON WINNING SPECIAL SECTION: SOCIAL IMPACT & IMPACT SCORE */}
      <section id="social-impact" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-b from-teal-50/60 via-white to-blue-50/40 rounded-3xl p-8 sm:p-12 border border-teal-200/70 shadow-sm space-y-12">
          <div className="text-center max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-100/80 px-3.5 py-1 rounded-full border border-teal-300">
              Hackathon Social Impact Spotlight
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-3 text-balance">
              Closing the Communication Gap for Deaf Individuals
            </h2>
            <p className="text-sm text-slate-600 mt-3 text-balance">
              More than 90% of deaf children are born to hearing parents, yet fewer than 15% of those parents achieve conversational sign fluency. BeyondWords removes learning friction so everyone can communicate freely.
            </p>
          </div>

          {/* Social Impact Image Showcase */}
          <div className="rounded-3xl overflow-hidden shadow-lg border border-slate-200 bg-slate-900 max-w-3xl mx-auto">
            <img
              src="/src/assets/images/deaf_community_impact_1793593869156.jpg"
              alt="Two people, deaf and hearing, communicating warmly using sign language in a bright cafe"
              className="w-full h-auto object-cover max-h-[420px]"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Impact Score Counter Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4">
            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs text-center">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                People Helped
              </span>
              <span className="text-3xl sm:text-4xl font-black text-blue-600 font-mono tabular-nums block mt-1">
                14,280+
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Learners bridging everyday communication barriers
              </span>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs text-center">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                Lessons Completed
              </span>
              <span className="text-3xl sm:text-4xl font-black text-teal-600 font-mono tabular-nums block mt-1">
                89,450+
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Interactive sign gesture practice sessions logged
              </span>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs text-center">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                Bridges Created
              </span>
              <span className="text-3xl sm:text-4xl font-black text-amber-600 font-mono tabular-nums block mt-1">
                62,100+
              </span>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Conversational connections formed across communities
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 6. TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Learner Stories
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 mt-2 text-balance">
            Real Impact from Everyday Signers
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <p className="text-xs text-slate-600 leading-relaxed italic">
              "My new coworker is deaf. Before BeyondWords, I felt awkward and isolated. After 2 weeks of practicing 10 minutes a day, I can now fingerspell her name, say hello, and exchange morning greetings. It completely changed our team dynamic."
            </p>
            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs">
                MR
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Marcus Reed</h4>
                <p className="text-[10px] text-slate-500">Software Product Manager · Chicago</p>
              </div>
            </div>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <p className="text-xs text-slate-600 leading-relaxed italic">
              "As a deaf educator, seeing AI give instantaneous visual feedback on finger curling rather than just a red 'wrong' mark is incredible. It teaches correct anatomy from day one without creating bad habits."
            </p>
            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-teal-100 text-teal-700 font-bold flex items-center justify-center text-xs">
                CL
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Dr. Claire Laurent</h4>
                <p className="text-[10px] text-slate-500">ASL Curriculum Advisor & Deaf Advocate</p>
              </div>
            </div>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <p className="text-xs text-slate-600 leading-relaxed italic">
              "The 30-second Quiz Arena turned practice into a daily family game. My 9-year-old daughter and I practice every evening to keep our streak alive. BeyondWords makes learning joyful and accessible."
            </p>
            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-700 font-bold flex items-center justify-center text-xs">
                ST
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900">Sarah Tanaka</h4>
                <p className="text-[10px] text-slate-500">Elementary School Teacher · Seattle</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. TEAM SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
            The Team
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 mt-2 text-balance">
            Passionate Builders for Universal Access
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div className="p-6 bg-white rounded-3xl border border-slate-200 text-center shadow-xs">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 font-bold text-xl flex items-center justify-center mx-auto mb-3">
              PG
            </div>
            <h4 className="text-sm font-bold text-slate-900">Pratha Goswami</h4>
            <p className="text-xs text-blue-600 font-medium">Lead Engineer & CV Architect</p>
            <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
              Specializes in client-side MediaPipe landmark pipelines and accessible web software.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-200 text-center shadow-xs">
            <div className="w-16 h-16 rounded-2xl bg-teal-50 text-teal-600 font-bold text-xl flex items-center justify-center mx-auto mb-3">
              DA
            </div>
            <h4 className="text-sm font-bold text-slate-900">Maya Chen</h4>
            <p className="text-xs text-teal-600 font-medium">Accessibility & Deaf UX Lead</p>
            <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
              Deaf culture researcher ensuring authentic facial grammar and cultural sensitivity.
            </p>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-200 text-center shadow-xs">
            <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 font-bold text-xl flex items-center justify-center mx-auto mb-3">
              RK
            </div>
            <h4 className="text-sm font-bold text-slate-900">David Kim</h4>
            <p className="text-xs text-indigo-600 font-medium">AI & Curriculum Designer</p>
            <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
              Designs interactive gamification progressions and Gemini tutor integration.
            </p>
          </div>
        </div>
      </section>

      {/* 8. CONTACT SECTION */}
      <section className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Get in Touch with BeyondWords</h2>
            <p className="text-xs text-slate-500 mt-1">
              Have feedback, community partnership ideas, or want to contribute new sign sets?
            </p>
          </div>

          {contactSubmitted ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs text-center">
              🎉 Thank you for reaching out! Our team will respond shortly.
            </div>
          ) : (
            <form onSubmit={handleContactSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    placeholder="Jordan Lee"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    placeholder="jordan@example.com"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Message</label>
                <textarea
                  rows={3}
                  required
                  value={contactMessage}
                  onChange={(e) => setContactMessage(e.target.value)}
                  placeholder="Share your thoughts, suggestions, or school partnership inquiries..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                Send Message
              </button>
            </form>
          )}
        </div>
      </section>

      {/* 9. FOOTER */}
      <footer className="border-t border-slate-200 pt-12 pb-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold">
              BW
            </span>
            <span className="font-extrabold text-slate-900">BeyondWords</span>
            <span className="text-slate-400">·</span>
            <span>Breaking Barriers Through Sign Language</span>
          </div>

          <div className="flex items-center gap-6">
            <span>Client-side vision privacy</span>
            <span>·</span>
            <span>WCAG 2.1 AA Accessible</span>
            <span>·</span>
            <span>© 2026 BeyondWords</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
