import React, { useState, useCallback } from 'react';
import {
  Volume2,
  ChevronLeft,
  ChevronRight,
  CheckCircle,
  HelpCircle,
  Zap,
} from 'lucide-react';
import { GestureDefinition, GestureCategory } from '../types';
import { GESTURES } from '../data/gestures';
import { HandGuideGraphic } from './HandGuideGraphic';
import { HandLandmarkCanvas } from './HandLandmarkCanvas';
import { CelebrationFeedback } from './CelebrationFeedback';
import { audioService } from '../services/audioService';
import { storageService } from '../services/storageService';

interface LessonModeProps {
  onOpenGuideForSign?: (signName: string) => void;
  onXPUpdated?: () => void;
}

export const LessonMode: React.FC<LessonModeProps> = ({
  onOpenGuideForSign,
  onXPUpdated,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<GestureCategory | 'all'>('all');
  const [currentGestureIndex, setCurrentGestureIndex] = useState(0);
  const [autoAdvance, setAutoAdvance] = useState(true);

  // Filter gestures by selected category
  const filteredGestures = GESTURES.filter((g) =>
    selectedCategory === 'all' ? true : g.category === selectedCategory
  );

  const currentGesture: GestureDefinition =
    filteredGestures[currentGestureIndex] || filteredGestures[0] || GESTURES[0];

  // Feedback State
  const [feedbackState, setFeedbackState] = useState<{
    status: 'correct' | 'incorrect' | null;
    accuracy: number;
    detectedSign: string;
    mistakeText?: string;
    tipText?: string;
  }>({
    status: null,
    accuracy: 0,
    detectedSign: '',
  });

  // Read instructions aloud using Web Speech API
  const handleSpeakInstructions = useCallback(() => {
    const textToSpeak = `Sign ${currentGesture.name}. ${currentGesture.shortDesc}. Formation: ${currentGesture.steps.join('. ')}`;
    audioService.speakInstruction(textToSpeak);
  }, [currentGesture.name, currentGesture.shortDesc, currentGesture.steps]);

  const handleVerifySign = useCallback(
    (
      accuracy: number,
      detectedSign: string,
      mistakeText?: string,
      tipText?: string
    ) => {
      const isSuccess =
        accuracy >= 75 &&
        (detectedSign === currentGesture.name || detectedSign === currentGesture.id);

      if (isSuccess) {
        storageService.addXP(25, currentGesture.id, accuracy);
        if (onXPUpdated) onXPUpdated();
        setFeedbackState({
          status: 'correct',
          accuracy,
          detectedSign,
        });
      } else {
        setFeedbackState({
          status: 'incorrect',
          accuracy,
          detectedSign: detectedSign || 'Unknown',
          mistakeText: mistakeText || currentGesture.commonMistakes[0],
          tipText: tipText || currentGesture.correctionTip,
        });
      }
    },
    [currentGesture, onXPUpdated]
  );

  // Called automatically when gesture is held & locked in by HandLandmarkCanvas
  const handleAutoConfirmed = useCallback(
    (res: {
      accuracy: number;
      detectedSign: string;
      mistakeText?: string;
      tipText?: string;
    }) => {
      handleVerifySign(res.accuracy, res.detectedSign, res.mistakeText, res.tipText);
    },
    [handleVerifySign]
  );

  const handleNextLesson = useCallback(() => {
    setFeedbackState({ status: null, accuracy: 0, detectedSign: '' });
    setCurrentGestureIndex((prev) => (prev < filteredGestures.length - 1 ? prev + 1 : 0));
  }, [filteredGestures.length]);

  const handlePrevLesson = useCallback(() => {
    setFeedbackState({ status: null, accuracy: 0, detectedSign: '' });
    setCurrentGestureIndex((prev) => (prev > 0 ? prev - 1 : filteredGestures.length - 1));
  }, [filteredGestures.length]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header and Curriculum Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-600 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200">
              Interactive Lesson Mode
            </span>
            <span className="text-xs text-slate-500">20 Certified Curriculum Gestures</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            Master Sign: "{currentGesture.name}"
          </h1>
        </div>

        {/* Category Filter Tabs & Auto-Advance Toggle */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setAutoAdvance(!autoAdvance)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              autoAdvance
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-2xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
            title="Automatically advance to the next sign after correct verification"
          >
            <Zap className={`w-3.5 h-3.5 ${autoAdvance ? 'text-emerald-600 animate-pulse' : 'text-slate-400'}`} />
            <span>Auto-Advance: {autoAdvance ? 'ON' : 'OFF'}</span>
          </button>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
            {(['all', 'letters', 'numbers', 'words'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  setCurrentGestureIndex(0);
                  setFeedbackState({ status: null, accuracy: 0, detectedSign: '' });
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg capitalize transition-colors ${
                  selectedCategory === cat
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat === 'all' ? 'All (20)' : cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Auto-Detection Help Banner with Color-Coded 4-Tier Indicator Guide */}
      <div className="my-3 p-3 bg-gradient-to-r from-blue-50/80 via-teal-50/60 to-emerald-50/80 border border-teal-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-2xs">
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
          <span className="font-bold text-slate-900">
            AI 4-Tier Recognition Confidence:
          </span>
          <span className="text-slate-600">
            Green &gt;90% Excellent · Teal 75-90% Good · Orange 60-75% Almost Correct · Red &lt;60% Try Again
          </span>
        </div>

        {/* Live Color Indicator Pills */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto shrink-0 flex-wrap">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            &gt;90% Excellent
          </span>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800 border border-teal-300">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
            75-90% Good
          </span>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            60-75% Adjust
          </span>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            &lt;60% Retry
          </span>
        </div>
      </div>

      {/* Horizontal Gestures Carousel / Quick Switcher */}
      <div className="py-2 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-2 min-w-max pb-1">
          {filteredGestures.map((gesture, idx) => {
            const isCurrent = idx === currentGestureIndex;
            const isCompleted = storageService
              .getUserProgress()
              .completedLessons.includes(gesture.id);

            return (
              <button
                key={gesture.id}
                onClick={() => {
                  setCurrentGestureIndex(idx);
                  setFeedbackState({ status: null, accuracy: 0, detectedSign: '' });
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  isCurrent
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm scale-105'
                    : isCompleted
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-blue-300'
                }`}
              >
                {isCompleted && (
                  <CheckCircle className={`w-3.5 h-3.5 ${isCurrent ? 'text-white' : 'text-emerald-600'}`} />
                )}
                <span>{gesture.name}</span>
                <span className={`text-[10px] ${isCurrent ? 'text-blue-200' : 'text-slate-400'}`}>
                  {gesture.category}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main 2-Zone Sandbox: Stage & Guide Deck */}
      <div className="mt-2.5 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Stage (Col 1-7): Live Webcam & AI Vision Tracking */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse" />
                <h2 className="text-sm font-bold text-slate-900">AI Hand Tracking Feed</h2>
              </div>
              <span className="text-xs text-slate-500">Color-Coded Biometric Lock Ring</span>
            </div>

            {/* Hand Landmark Webcam Canvas with stable callback */}
            <HandLandmarkCanvas
              targetGesture={currentGesture}
              onAutoConfirmed={handleAutoConfirmed}
            />

            {/* Action Verify Bar - shifted up */}
            <div className="mt-1.5 pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="flex items-center gap-2 -translate-y-0.5">
                <button
                  onClick={handlePrevLesson}
                  className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                  title="Previous Lesson"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-semibold text-slate-700">
                  {currentGestureIndex + 1} of {filteredGestures.length}
                </span>
                <button
                  onClick={handleNextLesson}
                  className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                  title="Next Lesson"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-2 -translate-y-1 sm:-translate-y-1.5">
                <button
                  onClick={() => handleVerifySign(96, currentGesture.name)}
                  className="w-full sm:w-auto px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 rounded-xl transition-all shadow-xs flex items-center justify-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Manual Verify
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Stage (Col 8-12): Hand Placement Guide & Step-by-Step Instructions */}
        <div className="lg:col-span-5 space-y-5">
          {/* Anatomical Landmark Placement Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-[11px] font-semibold text-blue-600 uppercase tracking-wider">
                  Target Blueprint
                </span>
                <h3 className="text-lg font-bold text-slate-900">Sign Placement Guide</h3>
              </div>
              <button
                onClick={handleSpeakInstructions}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors"
                title="Voice read instructions aloud (Web Speech API)"
              >
                <Volume2 className="w-3.5 h-3.5" />
                Speak Steps
              </button>
            </div>

            {/* Hand Guide Graphic */}
            <HandGuideGraphic gesture={currentGesture} size={240} />

            {/* Hand Orientation Tip */}
            <div className="mt-4 p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <span className="font-semibold text-slate-800">Hand Orientation: </span>
              <span className="text-slate-600">{currentGesture.handOrientation}</span>
            </div>
          </div>

          {/* Step-by-Step Formation & Tips */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Step-by-Step Formation</h3>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                {currentGesture.difficulty}
              </span>
            </div>

            <ol className="space-y-2.5 text-xs text-slate-700">
              {currentGesture.steps.map((step, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[10px]">
                    {idx + 1}
                  </span>
                  <span className="pt-0.5 leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>

            {/* Common Mistakes Warning */}
            <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs">
              <span className="font-bold text-amber-800 block mb-1">Common Pitfall:</span>
              <p className="text-amber-900 leading-relaxed">{currentGesture.commonMistakes[0]}</p>
            </div>

            {/* Need Help? Trigger BeyondWords Guide */}
            {onOpenGuideForSign && (
              <button
                onClick={() => onOpenGuideForSign(currentGesture.name)}
                className="w-full py-2.5 px-4 text-xs font-semibold text-blue-700 bg-blue-50/70 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <HelpCircle className="w-4 h-4 text-blue-600" />
                Ask "BeyondWords Guide" About "{currentGesture.name}"
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Instant Celebratory Feedback Modal with automatic voice result & auto-advance */}
      <CelebrationFeedback
        status={feedbackState.status}
        targetGesture={currentGesture}
        accuracy={feedbackState.accuracy}
        detectedSign={feedbackState.detectedSign}
        mistakeText={feedbackState.mistakeText}
        tipText={feedbackState.tipText}
        autoAdvance={autoAdvance}
        onNextLesson={handleNextLesson}
        onRetry={() => setFeedbackState({ status: null, accuracy: 0, detectedSign: '' })}
        onClose={() => setFeedbackState({ status: null, accuracy: 0, detectedSign: '' })}
      />
    </div>
  );
};
