import React from 'react';
import { Volume2, VolumeX, Eye, User, Sparkles } from 'lucide-react';
import { audioService } from '../services/audioService';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenAuth: () => void;
  isHighContrast: boolean;
  onToggleContrast: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  userLevel?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenAuth,
  isHighContrast,
  onToggleContrast,
  isMuted,
  onToggleMute,
  userLevel = 'Explorer',
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Strict 3-zone contract: Brand — 4-5 single line links — 1 primary action */}
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => onSelectTab('home')}
            className="text-xl font-extrabold tracking-tight text-blue-600 hover:text-blue-700 whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <span className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-teal-500 text-white flex items-center justify-center font-bold text-sm shadow-xs">
              BW
            </span>
            <span className="text-slate-900 font-black">BeyondWords</span>
          </button>

          {/* Zone 2: 4-5 clean single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
            <button
              onClick={() => onSelectTab('lessons')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'lessons' ? 'text-blue-600 font-bold' : ''
              }`}
            >
              Lessons
            </button>
            <button
              onClick={() => onSelectTab('quiz')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'quiz' ? 'text-blue-600 font-bold' : ''
              }`}
            >
              Quiz Arena
            </button>
            <button
              onClick={() => onSelectTab('dashboard')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'dashboard' ? 'text-blue-600 font-bold' : ''
              }`}
            >
              Gamification
            </button>
            <button
              onClick={() => onSelectTab('impact')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'impact' ? 'text-blue-600 font-bold' : ''
              }`}
            >
              Social Impact
            </button>
            <button
              onClick={() => onSelectTab('admin')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'admin' ? 'text-blue-600 font-bold' : ''
              }`}
            >
              Admin
            </button>
          </nav>

          {/* Zone 3: 1 primary action + accessible utilities */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Accessibility Controls */}
            <button
              onClick={onToggleContrast}
              className={`p-2 rounded-xl border transition-colors ${
                isHighContrast
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'text-slate-500 hover:text-slate-800 border-slate-200 hover:bg-slate-50'
              }`}
              title="Toggle High Contrast Mode"
              aria-label="Toggle High Contrast Mode"
            >
              <Eye className="w-4 h-4" />
            </button>

            <button
              onClick={onToggleMute}
              className={`p-2 rounded-xl border transition-colors ${
                isMuted
                  ? 'bg-rose-50 text-rose-600 border-rose-200'
                  : 'text-slate-500 hover:text-slate-800 border-slate-200 hover:bg-slate-50'
              }`}
              title={isMuted ? 'Unmute Sound Effects' : 'Mute Sound Effects'}
              aria-label="Toggle Audio Mute"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Profile Avatar / Login Button */}
            <button
              onClick={() => onSelectTab('profile')}
              className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap shrink-0"
              title="Open Profile"
            >
              <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold">
                A
              </div>
              <span className="hidden sm:inline font-medium">Profile</span>
            </button>

            {/* Primary Action Button */}
            <button
              onClick={() => onSelectTab('lessons')}
              className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              Start Learning
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-100 text-xs font-medium text-slate-600">
          <button
            onClick={() => onSelectTab('lessons')}
            className={`py-1 ${currentTab === 'lessons' ? 'text-blue-600 font-bold' : ''}`}
          >
            Lessons
          </button>
          <button
            onClick={() => onSelectTab('quiz')}
            className={`py-1 ${currentTab === 'quiz' ? 'text-blue-600 font-bold' : ''}`}
          >
            Quiz
          </button>
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`py-1 ${currentTab === 'dashboard' ? 'text-blue-600 font-bold' : ''}`}
          >
            Stats & XP
          </button>
          <button
            onClick={() => onSelectTab('impact')}
            className={`py-1 ${currentTab === 'impact' ? 'text-blue-600 font-bold' : ''}`}
          >
            Impact
          </button>
        </div>
      </div>
    </header>
  );
};
