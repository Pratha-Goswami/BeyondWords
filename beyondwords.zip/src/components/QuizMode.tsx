import React, { useState, useEffect, useRef } from 'react';
import { Timer, Trophy, CheckCircle, XCircle, Play, RotateCcw, Award, Zap } from 'lucide-react';
import { GestureDefinition } from '../types';
import { GESTURES } from '../data/gestures';
import { HandLandmarkCanvas } from './HandLandmarkCanvas';
import { audioService } from '../services/audioService';
import { storageService } from '../services/storageService';
import confetti from 'canvas-confetti';

interface QuizModeProps {
  onXPUpdated?: () => void;
}

export const QuizMode: React.FC<QuizModeProps> = ({ onXPUpdated }) => {
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [gameState, setGameState] = useState<'idle' | 'active' | 'finished'>('idle');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [quizQuestions, setQuizQuestions] = useState<GestureDefinition[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [answersLog, setAnswersLog] = useState<{
    gesture: string;
    isCorrect: boolean;
    accuracy: number;
  }[]>([]);

  const timerRef = useRef<any>(null);
  const isQuestionTransitioning = useRef<boolean>(false);

  // Filter pool based on difficulty
  const startQuiz = () => {
    let pool = [...GESTURES];
    if (difficulty === 'Easy') {
      pool = GESTURES.filter((g) => g.category === 'letters' || g.category === 'numbers');
    } else if (difficulty === 'Hard') {
      pool = GESTURES.filter((g) => g.category === 'words' || g.difficulty === 'Intermediate');
    }

    // Shuffle and pick 5 questions
    const shuffled = pool.sort(() => 0.5 - Math.random()).slice(0, 5);
    setQuizQuestions(shuffled);
    setCurrentQuestionIndex(0);
    setScore(0);
    setTimeLeft(30);
    setAnswersLog([]);
    setGameState('active');
    isQuestionTransitioning.current = false;

    // Announce first question
    if (shuffled[0]) {
      audioService.speakInstruction(`Quiz started! First sign: ${shuffled[0].name}`);
    }
  };

  // 30 seconds countdown timer
  useEffect(() => {
    if (gameState === 'active' && timeLeft > 0) {
      timerRef.current = setTimeout(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (gameState === 'active' && timeLeft === 0) {
      finishQuiz();
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [gameState, timeLeft]);

  const currentTarget = quizQuestions[currentQuestionIndex];

  // Automatic verification handler
  const handleLiveVerification = (accuracy: number, detectedSign: string) => {
    if (gameState !== 'active' || !currentTarget || isQuestionTransitioning.current) return;

    const isMatch =
      accuracy >= 75 && (detectedSign === currentTarget.name || detectedSign === currentTarget.id);

    if (isMatch) {
      isQuestionTransitioning.current = true;
      audioService.playSuccess();
      audioService.speakInstruction(`Correct! Sign ${currentTarget.name} verified. Plus 10 points!`);

      confetti({
        particleCount: 50,
        spread: 45,
        origin: { y: 0.7 },
      });

      setScore((s) => s + 10);
      setAnswersLog((log) => [
        ...log,
        { gesture: currentTarget.name, isCorrect: true, accuracy },
      ]);

      setTimeout(() => {
        isQuestionTransitioning.current = false;
        advanceQuestion();
      }, 1200);
    }
  };

  const advanceQuestion = () => {
    if (currentQuestionIndex < quizQuestions.length - 1) {
      const nextIndex = currentQuestionIndex + 1;
      setCurrentQuestionIndex(nextIndex);
      const nextTarget = quizQuestions[nextIndex];
      if (nextTarget) {
        audioService.speakInstruction(`Next sign: ${nextTarget.name}`);
      }
    } else {
      finishQuiz();
    }
  };

  const handleSkipQuestion = () => {
    if (gameState !== 'active' || !currentTarget || isQuestionTransitioning.current) return;
    audioService.playRetry();
    audioService.speakInstruction(`Skipped ${currentTarget.name}`);
    setAnswersLog((log) => [
      ...log,
      { gesture: currentTarget.name, isCorrect: false, accuracy: 0 },
    ]);
    advanceQuestion();
  };

  const finishQuiz = () => {
    setGameState('finished');
    if (timerRef.current) clearTimeout(timerRef.current);

    audioService.playLessonComplete();
    audioService.speakInstruction(`Quiz complete! You scored ${score} points!`);

    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
    });

    storageService.recordQuizScore(score, quizQuestions.length * 10, difficulty);
    if (onXPUpdated) onXPUpdated();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Quiz Header */}
      <div className="text-center mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
          Real-Time Assessment
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 mt-2">Sign Language Quiz Arena</h1>
        <p className="text-sm text-slate-500 mt-1">
          Auto-gesture recognition is active! Simply form each sign to score points and advance automatically.
        </p>
      </div>

      {gameState === 'idle' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm text-center max-w-lg mx-auto space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <Trophy className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-xl font-bold text-slate-900">Choose Your Difficulty</h2>
            <p className="text-xs text-slate-500 mt-1">
              5 randomized signs with hands-free auto verification. Score +10 points per verified sign!
            </p>
          </div>

          <div className="flex justify-center gap-2">
            {(['Easy', 'Medium', 'Hard'] as const).map((diff) => (
              <button
                key={diff}
                onClick={() => setDifficulty(diff)}
                className={`px-4 py-2 text-xs font-semibold rounded-xl border transition-all ${
                  difficulty === diff
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {diff}
              </button>
            ))}
          </div>

          <div className="pt-2">
            <button
              onClick={startQuiz}
              className="w-full py-3 px-6 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-sm flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              Start 30-Second Quiz
            </button>
          </div>
        </div>
      )}

      {gameState === 'active' && currentTarget && (
        <div className="space-y-6">
          {/* Status HUD: Timer and Score */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Timer className={`w-5 h-5 ${timeLeft <= 5 ? 'text-rose-600 animate-ping' : 'text-blue-600'}`} />
              <span className="text-xs font-semibold text-slate-600">Time Remaining:</span>
              <span className={`text-lg font-mono font-bold tabular-nums ${timeLeft <= 5 ? 'text-rose-600' : 'text-slate-900'}`}>
                {timeLeft}s
              </span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-xs font-semibold text-slate-500">
                Question {currentQuestionIndex + 1} of {quizQuestions.length}
              </span>
              <div className="px-3 py-1 bg-amber-50 border border-amber-200 rounded-lg text-xs font-bold text-amber-800">
                Score: {score} pts
              </div>
            </div>
          </div>

          {/* Prompt Banner */}
          <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-6 text-white text-center shadow-md relative overflow-hidden">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur rounded-full text-xs font-bold mb-1">
              <Zap className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
              <span>Auto-Detect Active: Hold Sign to Submit</span>
            </div>
            <div className="text-4xl sm:text-5xl font-black tracking-tight mt-1">
              "{currentTarget.name}"
            </div>
            <p className="text-xs text-blue-100 mt-2 max-w-sm mx-auto">
              {currentTarget.shortDesc}
            </p>
          </div>

          {/* AI Camera Tracker with Auto-Confirmation */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs">
            <HandLandmarkCanvas
              targetGesture={currentTarget}
              onEvaluationResult={() => {}}
              onAutoConfirmed={(res) => {
                handleLiveVerification(res.accuracy, res.detectedSign);
              }}
            />

            <div className="mt-4 flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={handleSkipQuestion}
                className="text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors"
              >
                Skip This Sign
              </button>
              <button
                onClick={() => handleLiveVerification(96, currentTarget.name)}
                className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
              >
                Instant Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {gameState === 'finished' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-lg text-center max-w-lg mx-auto space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <h2 className="text-2xl font-black text-slate-900">Quiz Completed!</h2>
            <p className="text-xs text-slate-500 mt-1">
              Great job practicing your fast fingerspelling and sign reflexes.
            </p>
          </div>

          {/* Score Box */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <span className="text-xs text-slate-500">Final Score</span>
              <p className="text-3xl font-black text-blue-600 mt-1">{score} pts</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <span className="text-xs text-slate-500">XP Gained</span>
              <p className="text-3xl font-black text-emerald-600 mt-1">+{score} XP</p>
            </div>
          </div>

          {/* Answer Breakdown */}
          <div className="space-y-2 text-left">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Question Summary
            </span>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {answersLog.map((log, i) => (
                <div
                  key={i}
                  className="p-2.5 rounded-xl border flex items-center justify-between text-xs bg-slate-50 border-slate-200"
                >
                  <div className="flex items-center gap-2">
                    {log.isCorrect ? (
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-600" />
                    )}
                    <span className="font-semibold text-slate-800">Sign: {log.gesture}</span>
                  </div>
                  <span className="font-mono text-slate-500">{log.isCorrect ? '+10 pts' : '0 pts'}</span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={startQuiz}
            className="w-full py-3 px-6 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-sm flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Play Again
          </button>
        </div>
      )}
    </div>
  );
};
