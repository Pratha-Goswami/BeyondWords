import React, { useState } from 'react';
import {
  User,
  Mail,
  Shield,
  KeyRound,
  RotateCcw,
  CheckCircle2,
  Calendar,
  Flame,
  Award,
  Zap,
} from 'lucide-react';
import { storageService, BADGE_DEFINITIONS } from '../services/storageService';
import { GESTURES } from '../data/gestures';

interface UserProfileProps {
  onBackToLessons: () => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({ onBackToLessons }) => {
  const [user, setUser] = useState(storageService.getUserProgress());
  const [isEditing, setIsEditing] = useState(false);
  const [nameInput, setNameInput] = useState(user.name);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  const handleUpdateName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;

    const updated = { ...user, name: nameInput.trim() };
    storageService.saveUserProgress(updated);
    setUser(updated);
    setIsEditing(false);
    setStatusMessage('Profile name updated successfully!');
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setStatusMessage('New password must be at least 6 characters.');
      return;
    }
    setOldPassword('');
    setNewPassword('');
    setStatusMessage('Password updated successfully for local session!');
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const handleResetData = () => {
    if (confirm('Are you sure you want to reset your local demo practice history?')) {
      storageService.resetData();
      setUser(storageService.getUserProgress());
      setStatusMessage('Practice data reset to default demo state.');
      setTimeout(() => setStatusMessage(''), 3000);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Profile Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-teal-500 text-white flex items-center justify-center text-2xl font-bold shadow-md">
            {user.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-slate-900">{user.name}</h1>
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                {user.level}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              <span>{user.email}</span>
              <span>·</span>
              <span>Streak: {user.streakDays} Days</span>
            </p>
          </div>
        </div>

        <button
          onClick={onBackToLessons}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
        >
          Back to Lessons
        </button>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Main Grid: Details & Password Settings */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Left Column (Col 1-7): Statistics & Practice History */}
        <div className="md:col-span-7 space-y-6">
          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs text-center">
              <span className="text-[11px] text-slate-500 block">Total XP</span>
              <span className="text-xl font-bold text-blue-600 font-mono tabular-nums">
                {user.xp}
              </span>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs text-center">
              <span className="text-[11px] text-slate-500 block">Signs Mastered</span>
              <span className="text-xl font-bold text-teal-600 font-mono tabular-nums">
                {user.completedLessons.length} / {GESTURES.length}
              </span>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs text-center">
              <span className="text-[11px] text-slate-500 block">Daily Streak</span>
              <span className="text-xl font-bold text-amber-600 font-mono tabular-nums">
                {user.streakDays}d
              </span>
            </div>
          </div>

          {/* Practice History Log */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Recent Practice & Quiz Log</h2>
            <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
              {user.quizScores.length > 0 ? (
                user.quizScores.map((score, i) => (
                  <div key={i} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-semibold text-slate-800">
                        {score.difficulty} Level Speed Quiz
                      </span>
                      <p className="text-[11px] text-slate-400 mt-0.5">{score.date}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-blue-600">
                        {score.score} / {score.total} pts
                      </span>
                      <span className="block text-[10px] text-emerald-600 font-semibold">
                        +{score.score} XP Gained
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-500 py-4 text-center">
                  No quiz sessions logged yet. Complete a quiz to track your history!
                </p>
              )}
            </div>
          </div>

          {/* Unlocked Badges */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Unlocked Badges ({user.unlockedBadges.length})</h2>
            <div className="grid grid-cols-2 gap-3">
              {user.unlockedBadges.map((badgeKey) => {
                const b = BADGE_DEFINITIONS[badgeKey];
                if (!b) return null;
                return (
                  <div
                    key={badgeKey}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-3"
                  >
                    <span className="text-2xl">{b.icon}</span>
                    <div>
                      <h3 className="text-xs font-bold text-slate-900">{b.title}</h3>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{b.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (Col 8-12): Profile Editing & Security Settings */}
        <div className="md:col-span-5 space-y-6">
          {/* Edit Profile Info */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Profile Information</h2>
            <form onSubmit={handleUpdateName} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email (read-only)
                </label>
                <input
                  type="email"
                  disabled
                  value={user.email}
                  className="w-full px-3 py-2 text-xs bg-slate-100 border border-slate-200 rounded-xl text-slate-500 cursor-not-allowed"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs"
              >
                Save Profile Name
              </button>
            </form>
          </div>

          {/* Change Password UI */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-slate-600" />
              <h2 className="text-base font-bold text-slate-900">Security & Password</h2>
            </div>
            <form onSubmit={handlePasswordChange} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 px-4 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Update Password
              </button>
            </form>
          </div>

          {/* Reset Demo Data */}
          <div className="p-4 bg-rose-50/50 rounded-2xl border border-rose-200 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-rose-900">Reset Demo History</h3>
              <p className="text-[11px] text-rose-700">Clear local storage and restore defaults</p>
            </div>
            <button
              onClick={handleResetData}
              className="p-2 text-rose-700 hover:bg-rose-100 rounded-lg transition-colors"
              title="Reset progress"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
