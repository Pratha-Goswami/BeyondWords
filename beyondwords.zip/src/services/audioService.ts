// Web Audio API Synthesizer & Web Speech API Voice Narrator

let audioCtx: AudioContext | null = null;
let isMuted = false;
let isVoiceEnabled = true;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export const audioService = {
  getIsMuted: () => isMuted,
  setMuted: (muted: boolean) => {
    isMuted = muted;
  },
  toggleMute: () => {
    isMuted = !isMuted;
    return isMuted;
  },

  getIsVoiceEnabled: () => isVoiceEnabled,
  setVoiceEnabled: (enabled: boolean) => {
    isVoiceEnabled = enabled;
  },
  toggleVoice: () => {
    isVoiceEnabled = !isVoiceEnabled;
    return isVoiceEnabled;
  },

  // Pleasant success chime: Major triad arpeggio (C5 -> E5 -> G5 -> C6) with soft decay
  playSuccess: () => {
    if (isMuted) return;
    const ctx = getAudioContext();
    if (!ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    const startTime = ctx.currentTime;

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime + idx * 0.08);

      gain.gain.setValueAtTime(0, startTime + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.2, startTime + idx * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + idx * 0.08 + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime + idx * 0.08);
      osc.stop(startTime + idx * 0.08 + 0.45);
    });
  },

  // Soft retry sound: gentle mellow dual-tone (no harsh buzzy sounds)
  playRetry: () => {
    if (isMuted) return;
    const ctx = getAudioContext();
    if (!ctx) return;

    const startTime = ctx.currentTime;
    const freqs = [329.63, 293.66]; // E4 down to D4

    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime + idx * 0.12);

      gain.gain.setValueAtTime(0, startTime + idx * 0.12);
      gain.gain.linearRampToValueAtTime(0.12, startTime + idx * 0.12 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + idx * 0.12 + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime + idx * 0.12);
      osc.stop(startTime + idx * 0.12 + 0.35);
    });
  },

  // Achievement Unlocked: Royal celebratory ascending fanfare
  playAchievement: () => {
    if (isMuted) return;
    const ctx = getAudioContext();
    if (!ctx) return;

    const startTime = ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880, 1108.73]; // A4, C#5, E5, A5, C#6

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime + idx * 0.1);

      gain.gain.setValueAtTime(0, startTime + idx * 0.1);
      gain.gain.linearRampToValueAtTime(0.25, startTime + idx * 0.1 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + idx * 0.1 + 0.6);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime + idx * 0.1);
      osc.stop(startTime + idx * 0.1 + 0.65);
    });
  },

  // Lesson Complete: Applause & celebratory harmony
  playLessonComplete: () => {
    if (isMuted) return;
    const ctx = getAudioContext();
    if (!ctx) return;

    const startTime = ctx.currentTime;
    // Harmonic chords
    const chord1 = [523.25, 659.25, 783.99]; // C major
    const chord2 = [587.33, 739.99, 880.0];  // D major
    const chord3 = [659.25, 830.61, 987.77]; // E major
    const chord4 = [1046.5, 1318.5, 1567.98]; // C6 octave flourish

    const chords = [
      { notes: chord1, time: 0 },
      { notes: chord2, time: 0.2 },
      { notes: chord3, time: 0.4 },
      { notes: chord4, time: 0.7 },
    ];

    chords.forEach(({ notes, time }) => {
      notes.forEach((freq) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, startTime + time);
        gain.gain.setValueAtTime(0.12, startTime + time);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + time + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime + time);
        osc.stop(startTime + time + 0.65);
      });
    });
  },

  // Web Speech API Voice Instructions
  speakInstruction: (text: string) => {
    if (!isVoiceEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }
    try {
      window.speechSynthesis.cancel(); // Stop any pending speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.05;
      utterance.volume = 0.85;

      // Prefer natural English voices if available
      const voices = window.speechSynthesis.getVoices();
      const naturalVoice = voices.find(
        (v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha') || v.name.includes('Daniel'))
      );
      if (naturalVoice) {
        utterance.voice = naturalVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis unavailable:', e);
    }
  },

  stopSpeaking: () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  },
};
