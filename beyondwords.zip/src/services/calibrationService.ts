export interface UserCalibrationProfile {
  timestamp: string;
  palmScale: number; // baseline wrist to middle MCP
  totalHandLength: number; // wrist to middle fingertip
  fingerProportions: {
    thumb: number;
    index: number;
    middle: number;
    ring: number;
    pinky: number;
  };
  preferredDistance: 'close' | 'optimal' | 'far';
  isCalibrated: boolean;
}

const STORAGE_KEY = 'beyondwords_user_calibration';

const DEFAULT_CALIBRATION: UserCalibrationProfile = {
  timestamp: new Date().toISOString(),
  palmScale: 0.22,
  totalHandLength: 0.42,
  fingerProportions: {
    thumb: 0.24,
    index: 0.32,
    middle: 0.35,
    ring: 0.32,
    pinky: 0.26,
  },
  preferredDistance: 'optimal',
  isCalibrated: false,
};

export const calibrationService = {
  getProfile(): UserCalibrationProfile {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to parse calibration profile:', e);
    }
    return DEFAULT_CALIBRATION;
  },

  saveProfile(profile: Partial<UserCalibrationProfile>): UserCalibrationProfile {
    const current = this.getProfile();
    const updated: UserCalibrationProfile = {
      ...current,
      ...profile,
      timestamp: new Date().toISOString(),
      isCalibrated: true,
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save calibration profile:', e);
    }
    return updated;
  },

  resetProfile(): UserCalibrationProfile {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {
      console.error('Failed to reset calibration profile:', e);
    }
    return DEFAULT_CALIBRATION;
  },
};
