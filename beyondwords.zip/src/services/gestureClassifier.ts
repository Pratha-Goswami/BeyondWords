import { LandmarkPoint, HandDetectionResult, GestureDefinition } from '../types';
import { GESTURES } from '../data/gestures';
import { tfGestureClassifier, CORE_GESTURES, calculateJointAngle } from './tfGestureModel';
import { calibrationService } from './calibrationService';

// Euclidean distance between two 2D/3D points
export function calculateDistance(p1: LandmarkPoint, p2: LandmarkPoint): number {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;
  const dz = (p1.z || 0) - (p2.z || 0);
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

// MediaPipe 21 Hand Connections
export const HAND_CONNECTIONS: [number, number][] = [
  // Thumb
  [0, 1], [1, 2], [2, 3], [3, 4],
  // Index
  [0, 5], [5, 6], [6, 7], [7, 8],
  // Middle
  [0, 9], [9, 10], [10, 11], [11, 12],
  // Ring
  [0, 13], [13, 14], [14, 15], [15, 16],
  // Pinky
  [0, 17], [17, 18], [18, 19], [19, 20],
  // Palm connections
  [5, 9], [9, 13], [13, 17],
];

// Landmark indices for each finger
export const FINGER_LANDMARKS = {
  thumb: [1, 2, 3, 4],
  index: [5, 6, 7, 8],
  middle: [9, 10, 11, 12],
  ring: [13, 14, 15, 16],
  pinky: [17, 18, 19, 20],
  palm: [0, 5, 9, 13, 17],
};

/**
 * Exponential Moving Average (EMA) Landmark Smoothing
 * Significantly reduces jitter and landmark vibration while keeping movement responsive.
 */
export function smoothLandmarks(
  current: LandmarkPoint[],
  previous: LandmarkPoint[] | null,
  alpha = 0.68
): LandmarkPoint[] {
  if (!previous || previous.length !== current.length) {
    return current;
  }

  return current.map((currPt, idx) => {
    const prevPt = previous[idx];
    const dx = currPt.x - prevPt.x;
    const dy = currPt.y - prevPt.y;
    const speed = Math.sqrt(dx * dx + dy * dy);

    // If moving very fast, lower alpha so landmarks track hand without sluggishness
    const dynamicAlpha = speed > 0.04 ? 0.35 : alpha;

    return {
      x: prevPt.x * dynamicAlpha + currPt.x * (1 - dynamicAlpha),
      y: prevPt.y * dynamicAlpha + currPt.y * (1 - dynamicAlpha),
      z: (prevPt.z || 0) * dynamicAlpha + (currPt.z || 0) * (1 - dynamicAlpha),
    };
  });
}

/**
 * Computes normalized finger extension ratios [thumb, index, middle, ring, pinky]
 * 0.0 = completely curled/folded into palm
 * 1.0 = fully extended straight out
 * Incorporates user calibration if available.
 */
export function extractFingerExtensions(landmarks: LandmarkPoint[]): [number, number, number, number, number] {
  if (!landmarks || landmarks.length < 21) {
    return [0, 0, 0, 0, 0];
  }

  const userProfile = calibrationService.getProfile();
  const wrist = landmarks[0];
  const palmScale = calculateDistance(wrist, landmarks[9]) || userProfile.palmScale || 0.15;

  // Thumb: distance from tip (4) to pinky base (17) vs MCP (2)
  const thumbDist = calculateDistance(landmarks[4], landmarks[17]);
  const thumbExtended = Math.min(1, Math.max(0, (thumbDist / palmScale - 0.7) / 0.8));

  // Index (8 vs 6 vs 0)
  const indexTipDist = calculateDistance(landmarks[8], wrist);
  const indexPipDist = calculateDistance(landmarks[6], wrist);
  const indexExtended =
    indexTipDist > indexPipDist
      ? Math.min(1, Math.max(0, (indexTipDist - indexPipDist) / (palmScale * 0.7)))
      : 0.05;

  // Middle (12 vs 10 vs 0)
  const middleTipDist = calculateDistance(landmarks[12], wrist);
  const middlePipDist = calculateDistance(landmarks[10], wrist);
  const middleExtended =
    middleTipDist > middlePipDist
      ? Math.min(1, Math.max(0, (middleTipDist - middlePipDist) / (palmScale * 0.7)))
      : 0.05;

  // Ring (16 vs 14 vs 0)
  const ringTipDist = calculateDistance(landmarks[16], wrist);
  const ringPipDist = calculateDistance(landmarks[14], wrist);
  const ringExtended =
    ringTipDist > ringPipDist
      ? Math.min(1, Math.max(0, (ringTipDist - ringPipDist) / (palmScale * 0.7)))
      : 0.05;

  // Pinky (20 vs 18 vs 0)
  const pinkyTipDist = calculateDistance(landmarks[20], wrist);
  const pinkyPipDist = calculateDistance(landmarks[18], wrist);
  const pinkyExtended =
    pinkyTipDist > pinkyPipDist
      ? Math.min(1, Math.max(0, (pinkyTipDist - pinkyPipDist) / (palmScale * 0.7)))
      : 0.05;

  return [
    Math.round(thumbExtended * 100) / 100,
    Math.round(indexExtended * 100) / 100,
    Math.round(middleExtended * 100) / 100,
    Math.round(ringExtended * 100) / 100,
    Math.round(pinkyExtended * 100) / 100,
  ];
}

export interface FingerAccuracyStatus {
  thumb: boolean;
  index: boolean;
  middle: boolean;
  ring: boolean;
  pinky: boolean;
}

/**
 * Detailed error analysis comparing user landmarks to target sign.
 * Returns overall accuracy, error guidance, and per-finger accuracy for split-screen comparison.
 */
export function analyzeMistakes(
  extensions: [number, number, number, number, number],
  target: GestureDefinition,
  landmarks: LandmarkPoint[]
): {
  isCorrect: boolean;
  accuracy: number;
  mistakeText?: string;
  tipText?: string;
  fingerAccuracy: FingerAccuracyStatus;
} {
  const [tExt, iExt, mExt, rExt, pExt] = extensions;
  const [targetT, targetI, targetM, targetR, targetP] = target.idealFingerExtensions;

  // Differences for each finger
  const diffT = Math.abs(tExt - targetT);
  const diffI = Math.abs(iExt - targetI);
  const diffM = Math.abs(mExt - targetM);
  const diffR = Math.abs(rExt - targetR);
  const diffP = Math.abs(pExt - targetP);

  const fingerAccuracy: FingerAccuracyStatus = {
    thumb: diffT <= 0.35,
    index: diffI <= 0.32,
    middle: diffM <= 0.32,
    ring: diffR <= 0.35,
    pinky: diffP <= 0.35,
  };

  const wrist = landmarks[0];
  const palmScale = calculateDistance(wrist, landmarks[9]) || 0.15;
  const thumbIndexTipDist = calculateDistance(landmarks[4], landmarks[8]) / palmScale;
  const indexMiddleTipDist = calculateDistance(landmarks[8], landmarks[12]) / palmScale;

  let score = 100 - (diffT * 22 + diffI * 26 + diffM * 24 + diffR * 14 + diffP * 14);
  let specificMistake: string | undefined;

  switch (target.id) {
    case 'A':
      if (iExt > 0.32 || mExt > 0.32) {
        specificMistake = 'Close your fingers into a tighter fist.';
        score -= 25;
        fingerAccuracy.index = false;
        fingerAccuracy.middle = false;
      } else if (tExt < 0.25) {
        specificMistake = 'Keep thumb straight along the side of your index finger.';
        score -= 15;
        fingerAccuracy.thumb = false;
      }
      break;

    case 'B':
      if (iExt < 0.65 || mExt < 0.65 || rExt < 0.65 || pExt < 0.65) {
        specificMistake = 'Extend all four fingers straight up.';
        score -= 25;
        if (iExt < 0.65) fingerAccuracy.index = false;
        if (mExt < 0.65) fingerAccuracy.middle = false;
        if (rExt < 0.65) fingerAccuracy.ring = false;
        if (pExt < 0.65) fingerAccuracy.pinky = false;
      } else if (tExt > 0.55) {
        specificMistake = 'Tuck thumb flat across your palm.';
        score -= 20;
        fingerAccuracy.thumb = false;
      } else if (indexMiddleTipDist > 0.45) {
        specificMistake = 'Keep your 4 fingers pressed tightly together.';
        score -= 15;
      }
      break;

    case 'C':
      if (thumbIndexTipDist < 0.22) {
        specificMistake = 'Open your hand more — keep an arc gap between thumb and fingers.';
        score -= 25;
        fingerAccuracy.thumb = false;
        fingerAccuracy.index = false;
      } else if (iExt > 0.85 && tExt > 0.85) {
        specificMistake = 'Curve your fingers into a "C" shape, don’t hold them flat.';
        score -= 20;
      }
      break;

    case 'D':
      if (iExt < 0.6) {
        specificMistake = 'Raise your index finger straight up.';
        score -= 30;
        fingerAccuracy.index = false;
      } else if (mExt > 0.4 || rExt > 0.4) {
        specificMistake = 'Curl middle and ring fingers down to touch the thumb.';
        score -= 25;
        fingerAccuracy.middle = false;
        fingerAccuracy.ring = false;
      }
      break;

    case 'E':
      if (iExt > 0.42 || mExt > 0.42) {
        specificMistake = 'Curl all four fingertips tightly down to rest on your thumb.';
        score -= 30;
        fingerAccuracy.index = false;
        fingerAccuracy.middle = false;
      }
      break;

    case '1':
      if (iExt < 0.65) {
        specificMistake = 'Point index finger straight up.';
        score -= 30;
        fingerAccuracy.index = false;
      } else if (mExt > 0.35 || tExt > 0.7) {
        specificMistake = 'Only extend the index finger. Hold other fingers closed.';
        score -= 20;
        fingerAccuracy.middle = false;
      }
      break;

    case '2':
      if (iExt < 0.6 || mExt < 0.6) {
        specificMistake = 'Raise both index and middle fingers.';
        score -= 30;
        fingerAccuracy.index = false;
        fingerAccuracy.middle = false;
      } else if (rExt > 0.35 || pExt > 0.35) {
        specificMistake = 'Fold ring and pinky fingers down with your thumb.';
        score -= 20;
        fingerAccuracy.ring = false;
        fingerAccuracy.pinky = false;
      }
      break;

    case '3':
      if (tExt < 0.5) {
        specificMistake = 'Extend your thumb out! In ASL, 3 requires the thumb.';
        score -= 30;
        fingerAccuracy.thumb = false;
      } else if (iExt < 0.6 || mExt < 0.6) {
        specificMistake = 'Extend index and middle fingers along with the thumb.';
        score -= 25;
        fingerAccuracy.index = false;
        fingerAccuracy.middle = false;
      }
      break;

    case '4':
      if (iExt < 0.6 || mExt < 0.6 || rExt < 0.6 || pExt < 0.6) {
        specificMistake = 'Extend all four fingers up and slightly spread.';
        score -= 30;
      } else if (tExt > 0.55) {
        specificMistake = 'Tuck thumb flat against the palm.';
        score -= 20;
        fingerAccuracy.thumb = false;
      }
      break;

    case '5':
      if (iExt < 0.6 || mExt < 0.6 || rExt < 0.6 || pExt < 0.6 || tExt < 0.6) {
        specificMistake = 'Open hand completely and spread all five fingers wide.';
        score -= 35;
      }
      break;

    default:
      break;
  }

  // If all fingers match target
  const allFingersMatch = Object.values(fingerAccuracy).every(Boolean);
  if (allFingersMatch && score < 88) {
    score = 92;
  }

  const normalizedScore = Math.min(99, Math.max(12, Math.round(score)));
  const isCorrect = normalizedScore >= 75;

  return {
    isCorrect,
    accuracy: normalizedScore,
    mistakeText: isCorrect ? undefined : (specificMistake || target.commonMistakes[0]),
    tipText: target.correctionTip,
    fingerAccuracy,
  };
}

/**
 * Predicts the gesture using an ensemble of TensorFlow.js Neural Network
 * and geometric feature constraints.
 */
export function predictGestureFromLandmarks(
  landmarks: LandmarkPoint[],
  handedness: 'Left' | 'Right' = 'Right'
): HandDetectionResult & {
  tfConfidence?: number;
  stabilityLabel: 'Excellent Match' | 'Good Match' | 'Almost Correct' | 'Try Again';
} {
  const extensions = extractFingerExtensions(landmarks);

  // 1. Run TensorFlow.js model prediction
  let tfPred = { sign: 'A', confidence: 0 };
  if (tfGestureClassifier.ready) {
    tfPred = tfGestureClassifier.predict(landmarks);
  }

  // 2. Geometric search across all gestures
  let bestGeometricSign = 'A';
  let bestScore = 0;

  for (const gesture of GESTURES) {
    const analysis = analyzeMistakes(extensions, gesture, landmarks);
    if (analysis.accuracy > bestScore) {
      bestScore = analysis.accuracy;
      bestGeometricSign = gesture.name;
    }
  }

  // 3. Ensemble reconciliation
  let finalSign = bestGeometricSign;
  let finalConfidence = bestScore;

  if (tfPred.confidence > 70 && CORE_GESTURES.includes(tfPred.sign as any)) {
    // If TF agrees with geometric or has high certainty
    if (tfPred.sign === bestGeometricSign) {
      finalConfidence = Math.min(99, Math.max(bestScore, tfPred.confidence + 5));
    } else if (tfPred.confidence >= 85) {
      finalSign = tfPred.sign;
      finalConfidence = tfPred.confidence;
    }
  }

  // 4. Map to Requirement 8 Confidence Tiers:
  // > 90% = Excellent Match
  // 75% - 90% = Good Match
  // 60% - 75% = Almost Correct
  // < 60% = Try Again
  let stabilityLabel: 'Excellent Match' | 'Good Match' | 'Almost Correct' | 'Try Again';
  if (finalConfidence >= 90) {
    stabilityLabel = 'Excellent Match';
  } else if (finalConfidence >= 75) {
    stabilityLabel = 'Good Match';
  } else if (finalConfidence >= 60) {
    stabilityLabel = 'Almost Correct';
  } else {
    stabilityLabel = 'Try Again';
  }

  return {
    landmarks,
    handedness,
    confidence: finalConfidence,
    detectedSign: finalSign,
    fingerExtensions: extensions,
    tfConfidence: tfPred.confidence,
    stabilityLabel,
  };
}

/**
 * Hand Bounding Box calculation with normalized coordinates
 */
export function calculateHandBoundingBox(landmarks: LandmarkPoint[]): {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  width: number;
  height: number;
  centerX: number;
  centerY: number;
} {
  if (!landmarks || landmarks.length === 0) {
    return { minX: 0, maxX: 0, minY: 0, maxY: 0, width: 0, height: 0, centerX: 0, centerY: 0 };
  }

  let minX = 1;
  let maxX = 0;
  let minY = 1;
  let maxY = 0;

  landmarks.forEach((pt) => {
    if (pt.x < minX) minX = pt.x;
    if (pt.x > maxX) maxX = pt.x;
    if (pt.y < minY) minY = pt.y;
    if (pt.y > maxY) maxY = pt.y;
  });

  const width = maxX - minX;
  const height = maxY - minY;
  const centerX = minX + width / 2;
  const centerY = minY + height / 2;

  return { minX, maxX, minY, maxY, width, height, centerX, centerY };
}

export interface HandPositionStatus {
  status: 'perfect' | 'closer' | 'back' | 'center' | 'out_of_frame';
  message: string;
  isFullyVisible: boolean;
  box: { minX: number; maxX: number; minY: number; maxY: number };
}

/**
 * Hand Positioning Guide & Proximity Inspector (Requirement 1 & 6)
 * Detects if hand is too far, too close, off-center, or outside frame.
 */
export function analyzeHandPosition(landmarks: LandmarkPoint[]): HandPositionStatus {
  if (!landmarks || landmarks.length < 21) {
    return {
      status: 'out_of_frame',
      message: 'No Hand Detected',
      isFullyVisible: false,
      box: { minX: 0, maxX: 0, minY: 0, maxY: 0 },
    };
  }

  const bbox = calculateHandBoundingBox(landmarks);
  const wrist = landmarks[0];
  const palmScale = calculateDistance(wrist, landmarks[9]) || 0.15;

  // Check if hand is cutting off at screen edges
  const edgeMargin = 0.03;
  const isTouchingEdge =
    bbox.minX < edgeMargin || bbox.maxX > 1 - edgeMargin || bbox.minY < edgeMargin || bbox.maxY > 1 - edgeMargin;

  if (isTouchingEdge) {
    return {
      status: 'out_of_frame',
      message: 'Hand Not Fully Visible',
      isFullyVisible: false,
      box: bbox,
    };
  }

  // Check proximity (palm scale or bbox area)
  if (palmScale < 0.13 || bbox.width < 0.16) {
    return {
      status: 'closer',
      message: 'Move Hand Closer',
      isFullyVisible: true,
      box: bbox,
    };
  }

  if (palmScale > 0.44 || bbox.width > 0.65 || bbox.height > 0.75) {
    return {
      status: 'back',
      message: 'Move Hand Back',
      isFullyVisible: true,
      box: bbox,
    };
  }

  // Check centering (ideal center box is 0.28 to 0.72)
  if (bbox.centerX < 0.28 || bbox.centerX > 0.72 || bbox.centerY < 0.22 || bbox.centerY > 0.78) {
    return {
      status: 'center',
      message: 'Center Your Hand',
      isFullyVisible: true,
      box: bbox,
    };
  }

  return {
    status: 'perfect',
    message: 'Perfect Position',
    isFullyVisible: true,
    box: bbox,
  };
}

/**
 * Video Lighting Luminance Inspector (Requirement 1 & 6)
 * Samples video pixels to evaluate brightness & contrast.
 */
export function evaluateVideoLighting(
  video: HTMLVideoElement,
  sampleCanvas: HTMLCanvasElement
): {
  luminance: number; // 0 - 255
  status: 'good' | 'low' | 'glare';
  message: string;
} {
  try {
    const ctx = sampleCanvas.getContext('2d', { willReadFrequently: true });
    if (!ctx || video.videoWidth === 0) {
      return { luminance: 130, status: 'good', message: 'Good Lighting' };
    }

    sampleCanvas.width = 48;
    sampleCanvas.height = 36;
    ctx.drawImage(video, 0, 0, 48, 36);

    const imgData = ctx.getImageData(0, 0, 48, 36);
    const data = imgData.data;

    let totalLuma = 0;
    const pixelCount = data.length / 4;

    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      // ITU-R BT.601 luminance formula
      totalLuma += 0.299 * r + 0.587 * g + 0.114 * b;
    }

    const avgLuma = Math.round(totalLuma / pixelCount);

    if (avgLuma < 50) {
      return { luminance: avgLuma, status: 'low', message: 'Lighting Too Low' };
    }
    if (avgLuma > 225) {
      return { luminance: avgLuma, status: 'glare', message: 'Lighting Too Bright / Glare' };
    }

    return { luminance: avgLuma, status: 'good', message: 'Good Lighting' };
  } catch (e) {
    return { luminance: 128, status: 'good', message: 'Good Lighting' };
  }
}

/**
 * Pre-recorded synthetic landmark prototypes for each of the 20 signs
 */
export function getSyntheticLandmarksForSign(signId: string): LandmarkPoint[] {
  const wrist: LandmarkPoint = { x: 0.5, y: 0.82, z: 0 };
  const target = GESTURES.find((g) => g.id === signId) || GESTURES[0];
  const [t, i, m, r, p] = target.idealFingerExtensions;

  const points: LandmarkPoint[] = [wrist];

  // Thumb (1, 2, 3, 4)
  const thumbAngle = t > 0.5 ? -0.7 : -0.2;
  const thumbLen = 0.08 + t * 0.12;
  points.push({ x: 0.46, y: 0.74, z: -0.01 });
  points.push({ x: 0.42, y: 0.67, z: -0.02 });
  points.push({
    x: 0.40 + Math.cos(thumbAngle) * thumbLen * 0.5,
    y: 0.62 + Math.sin(thumbAngle) * thumbLen * 0.5,
    z: -0.03,
  });
  points.push({
    x: 0.40 + Math.cos(thumbAngle) * thumbLen,
    y: 0.62 + Math.sin(thumbAngle) * thumbLen,
    z: -0.04,
  });

  // Index (5, 6, 7, 8)
  const indexBase = { x: 0.45, y: 0.58, z: 0 };
  const indexLen = 0.07 + i * 0.22;
  points.push(indexBase);
  points.push({ x: indexBase.x, y: indexBase.y - indexLen * 0.33, z: 0 });
  points.push({ x: indexBase.x, y: indexBase.y - indexLen * 0.66, z: 0 });
  points.push({ x: indexBase.x, y: indexBase.y - indexLen, z: 0 });

  // Middle (9, 10, 11, 12)
  const middleBase = { x: 0.50, y: 0.56, z: 0 };
  const middleLen = 0.07 + m * 0.24;
  points.push(middleBase);
  points.push({ x: middleBase.x, y: middleBase.y - middleLen * 0.33, z: 0 });
  points.push({ x: middleBase.x, y: middleBase.y - middleLen * 0.66, z: 0 });
  points.push({ x: middleBase.x, y: middleBase.y - middleLen, z: 0 });

  // Ring (13, 14, 15, 16)
  const ringBase = { x: 0.55, y: 0.58, z: 0 };
  const ringLen = 0.07 + r * 0.22;
  points.push(ringBase);
  points.push({ x: ringBase.x, y: ringBase.y - ringLen * 0.33, z: 0 });
  points.push({ x: ringBase.x, y: ringBase.y - ringLen * 0.66, z: 0 });
  points.push({ x: ringBase.x, y: ringBase.y - ringLen, z: 0 });

  // Pinky (17, 18, 19, 20)
  const pinkyBase = { x: 0.60, y: 0.62, z: 0 };
  const pinkyLen = 0.06 + p * 0.18;
  points.push(pinkyBase);
  points.push({ x: pinkyBase.x, y: pinkyBase.y - pinkyLen * 0.33, z: 0 });
  points.push({ x: pinkyBase.x, y: pinkyBase.y - pinkyLen * 0.66, z: 0 });
  points.push({ x: pinkyBase.x, y: pinkyBase.y - pinkyLen, z: 0 });

  return points;
}
