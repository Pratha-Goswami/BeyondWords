import { UserProgress } from '../types';

const STORAGE_KEY = 'beyondwords_user_progress';
const AUTH_KEY = 'beyondwords_auth_session';

export const DEFAULT_USER: UserProgress = {
  userId: 'user_demo_101',
  name: 'Alex Rivera',
  email: 'alex.rivera@example.com',
  xp: 320,
  level: 'Explorer',
  streakDays: 4,
  lastActiveDate: new Date().toISOString().split('T')[0],
  completedLessons: ['A', 'B', '1', '2', 'Hello'],
  gestureMastery: {
    A: 96,
    B: 92,
    1: 98,
    2: 94,
    Hello: 88,
  },
  quizScores: [
    { date: '2026-10-28', score: 40, total: 50, difficulty: 'Easy' },
    { date: '2026-10-30', score: 70, total: 80, difficulty: 'Medium' },
    { date: '2026-11-01', score: 90, total: 100, difficulty: 'Medium' },
  ],
  unlockedBadges: ['first_sign', 'alphabet_novice'],
};

export const BADGE_DEFINITIONS: Record<string, { title: string; desc: string; icon: string }> = {
  first_sign: {
    title: 'First Sign',
    desc: 'Practiced and mastered your very first ASL gesture.',
    icon: '👋',
  },
  alphabet_novice: {
    title: 'Alphabet Novice',
    desc: 'Learned at least 5 different ASL alphabet letters.',
    icon: '🔤',
  },
  number_wizard: {
    title: 'Number Wizard',
    desc: 'Correctly signed numbers 1 through 5.',
    icon: '🔢',
  },
  sharp_fingers: {
    title: 'Sharp Precision',
    desc: 'Achieved 95%+ accuracy on hand landmark placement.',
    icon: '🎯',
  },
  streak_keeper: {
    title: 'Streak Keeper',
    desc: 'Maintained a multi-day sign practice habit.',
    icon: '🔥',
  },
  master_communicator: {
    title: 'Master Communicator',
    desc: 'Practiced all 20 basic signs in the curriculum.',
    icon: '🏆',
  },
};

export const storageService = {
  getUserProgress: (): UserProgress => {
    if (typeof window === 'undefined') return DEFAULT_USER;
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.warn('Failed to load user progress:', e);
    }
    return DEFAULT_USER;
  },

  saveUserProgress: (progress: UserProgress) => {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch (e) {
      console.warn('Failed to save user progress:', e);
    }
  },

  addXP: (amount: number, gestureId?: string, accuracyScore?: number): UserProgress => {
    const current = storageService.getUserProgress();
    const newXP = current.xp + amount;

    // Recalculate level
    let newLevel: UserProgress['level'] = 'Beginner';
    if (newXP >= 1000) newLevel = 'Expert Signer';
    else if (newXP >= 500) newLevel = 'Communicator';
    else if (newXP >= 200) newLevel = 'Explorer';

    const completed = new Set(current.completedLessons);
    if (gestureId) completed.add(gestureId);

    const mastery = { ...current.gestureMastery };
    if (gestureId && accuracyScore) {
      mastery[gestureId] = Math.max(mastery[gestureId] || 0, accuracyScore);
    }

    // Check for badge unlocks
    const badges = new Set(current.unlockedBadges);
    if (completed.size >= 1) badges.add('first_sign');
    if (Array.from(completed).filter((id) => id.length === 1 && isNaN(Number(id))).length >= 5) {
      badges.add('alphabet_novice');
    }
    if (['1', '2', '3', '4', '5'].every((n) => completed.has(n))) {
      badges.add('number_wizard');
    }
    if (accuracyScore && accuracyScore >= 95) {
      badges.add('sharp_fingers');
    }
    if (completed.size >= 20) {
      badges.add('master_communicator');
    }

    const updated: UserProgress = {
      ...current,
      xp: newXP,
      level: newLevel,
      completedLessons: Array.from(completed),
      gestureMastery: mastery,
      unlockedBadges: Array.from(badges),
      lastActiveDate: new Date().toISOString().split('T')[0],
    };

    storageService.saveUserProgress(updated);
    return updated;
  },

  recordQuizScore: (score: number, total: number, difficulty: string): UserProgress => {
    const current = storageService.getUserProgress();
    const updated: UserProgress = {
      ...current,
      xp: current.xp + score,
      quizScores: [
        ...current.quizScores,
        {
          date: new Date().toISOString().split('T')[0],
          score,
          total,
          difficulty,
        },
      ],
    };
    storageService.saveUserProgress(updated);
    return updated;
  },

  // Auth session helpers
  getAuthSession: () => {
    if (typeof window === 'undefined') return { isLoggedIn: true, user: DEFAULT_USER };
    try {
      const data = localStorage.getItem(AUTH_KEY);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.warn('Failed to load auth session:', e);
    }
    return { isLoggedIn: true, user: DEFAULT_USER };
  },

  setAuthSession: (session: { isLoggedIn: boolean; user: Partial<UserProgress> }) => {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(AUTH_KEY, JSON.stringify(session));
    } catch (e) {
      console.warn('Failed to set auth session:', e);
    }
  },

  resetData: () => {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(AUTH_KEY);
  },
};
