export type GestureCategory = 'letters' | 'numbers' | 'words';
export type GestureDifficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export interface FingerState {
  thumb: 'extended' | 'folded' | 'tucked' | 'opposed';
  index: 'extended' | 'curled' | 'hooked' | 'horizontal';
  middle: 'extended' | 'curled' | 'crossed' | 'horizontal';
  ring: 'extended' | 'curled';
  pinky: 'extended' | 'curled';
}

export interface GestureDefinition {
  id: string;
  name: string;
  category: GestureCategory;
  difficulty: GestureDifficulty;
  shortDesc: string;
  handOrientation: string;
  steps: string[];
  commonMistakes: string[];
  correctionTip: string;
  fingerStateDescription: string;
  svgHandType: string;
  culturalNote?: string;
  // Ideal finger extension ratio: [thumb, index, middle, ring, pinky] (0 = folded, 1 = fully extended)
  idealFingerExtensions: [number, number, number, number, number];
}

export interface LandmarkPoint {
  x: number;
  y: number;
  z?: number;
}

export interface HandDetectionResult {
  landmarks: LandmarkPoint[];
  handedness: 'Left' | 'Right';
  confidence: number;
  detectedSign: string;
  fingerExtensions: [number, number, number, number, number];
}

export interface UserProgress {
  userId: string;
  name: string;
  email: string;
  xp: number;
  level: 'Beginner' | 'Explorer' | 'Communicator' | 'Expert Signer';
  streakDays: number;
  lastActiveDate: string;
  completedLessons: string[]; // gesture IDs
  gestureMastery: Record<string, number>; // gestureId -> accuracy percentage (0-100)
  quizScores: {
    date: string;
    score: number;
    total: number;
    difficulty: string;
  }[];
  unlockedBadges: string[];
}

export interface QuizQuestion {
  gesture: GestureDefinition;
  timeLimit: number; // in seconds
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  relatedSign?: string;
}
